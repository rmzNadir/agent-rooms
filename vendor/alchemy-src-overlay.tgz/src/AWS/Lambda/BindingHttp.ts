import * as Effect from "effect/Effect";
import type { Output as OutputType } from "../../Output.ts";
import * as AWSBindings from "../AWSBindings.ts";
import type { Function } from "./Function.ts";

/**
 * Shared scaffolding for AWS Lambda control/data-plane HTTP bindings.
 *
 * NOT exported from `index.ts` — every near-identical `{Op}Http.ts` in this
 * service is a thin `Layer.effect(Cap, make…HttpBinding({ … }))` over one of
 * the builders below. Everything except the operation, the IAM action list,
 * and the granted ARNs is boilerplate. How the host reaches AWS (native vs
 * external, see `AWSBindings.ts`) is handled by `AWSBindings.withCredentials`
 * and `AWSBindings.bind`.
 */

/** Region segment of an AWS ARN (`arn:partition:service:<region>:...`). */
export const regionFromArn = (arn: string): string => arn.split(":")[3] ?? "us-east-1";

/**
 * Build the impl Effect for a function-scoped operation (`Invoke`,
 * `GetFunction`, `InvokeWithResponseStream`): the runtime callable injects
 * the bound {@link Function}'s ARN as `FunctionName` and the deploy-time
 * half grants `actions` on `resources` (default: the function ARN).
 */
export const makeFunctionHttpBinding = <I extends { FunctionName?: string }, A, E, R>(options: {
  /** Fully-qualified binding tag, e.g. `AWS.Lambda.GetFunction`. */
  tag: string;
  /**
   * The distilled operation; `FunctionName` is injected from the function.
   * Resolved with the host's credentials (see `AWSBindings.withCredentials`),
   * signing in the function's region on an external host.
   */
  operation: Effect.Effect<(input: I) => Effect.Effect<A, E>, never, R>;
  /** IAM actions granted on `resources`. */
  actions: readonly string[];
  /** ARNs the actions are granted on. @default the function ARN */
  resources?: (func: Function) => (string | OutputType<string>)[];
}) =>
  Effect.gen(function* () {
    return Effect.fn(function* (func: Function) {
      const FunctionArn = yield* func.functionArn;
      // resolved per bind because an external host signs in the function's own region
      const op = yield* AWSBindings.withCredentials(
        options.operation,
        Effect.succeed(Effect.map(FunctionArn, regionFromArn)),
      );
      if (!globalThis.__ALCHEMY_RUNTIME__) {
        yield* AWSBindings.bind`${options.tag}(${func})`({
          policyStatements: [
            {
              Effect: "Allow",
              Action: [...options.actions],
              Resource: options.resources?.(func) ?? [func.functionArn],
            },
          ],
        });
      }
      return Effect.fn(`${options.tag}(${func.LogicalId})`)(function* (
        request?: Omit<I, "FunctionName">,
      ) {
        return yield* op({ ...request, FunctionName: yield* FunctionArn } as I);
      });
    });
  });

/**
 * Build the impl Effect for an account-level operation
 * (`GetAccountSettings`, `ListFunctions`): the runtime callable passes the
 * caller's request through unchanged and the deploy-time half grants
 * `actions` on `*` (these Lambda actions do not support resource-level
 * permissions).
 */
export const makeLambdaAccountHttpBinding = <I, A, E, R>(options: {
  /** Fully-qualified binding tag, e.g. `AWS.Lambda.ListFunctions`. */
  tag: string;
  /** The distilled operation, invoked with the caller's request as-is. */
  operation: Effect.Effect<(input: I) => Effect.Effect<A, E>, never, R>;
  /** IAM actions granted on `*`. */
  actions: readonly string[];
}) =>
  Effect.gen(function* () {
    const op = yield* AWSBindings.withCredentials(options.operation);

    return Effect.fn(function* () {
      if (!globalThis.__ALCHEMY_RUNTIME__) {
        yield* AWSBindings.bind`${options.tag}()`({
          policyStatements: [
            {
              Effect: "Allow",
              Action: [...options.actions],
              Resource: ["*"],
            },
          ],
        });
      }
      return Effect.fn(options.tag)(function* (request?: I) {
        return yield* op((request ?? {}) as I);
      });
    });
  });
