/** @effect-diagnostics layerMergeAllWithDependencies:off */
import { isRetryable, isThrottlingError, isTransientError } from "@distilled.cloud/aws/Category";
import { capped, jittered, Retry, type Factory as RetryFactory } from "@distilled.cloud/aws/Retry";
import * as Duration from "effect/Duration";
import * as Effect from "effect/Effect";
import { pipe } from "effect/Function";
import * as HttpClientError from "effect/http/HttpClientError";
import * as Layer from "effect/Layer";
import * as Ref from "effect/Ref";
import * as Schedule from "effect/Schedule";
import { CredentialsStoreLive } from "../Auth/Credentials.ts";
import * as Command from "../Command/index.ts";
import { DockerLive } from "../Docker/Docker.ts";
import { KeyPair, KeyPairProvider } from "../KeyPair.ts";
import * as ProviderLayer from "../Local/ProviderLayer.ts";
import * as Provider from "../Provider.ts";
import { defaultProviderMode } from "../ProviderMode.ts";
import { Random, RandomProvider } from "../Random.ts";
import {
  Server as WebsiteServer,
  ServerProvider as WebsiteServerProvider,
} from "../Website/Server.ts";
import * as AccessAnalyzer from "./AccessAnalyzer/index.ts";
import * as Account from "./Account/index.ts";
import * as ACM from "./ACM/index.ts";
import * as ACMPCA from "./ACMPCA/index.ts";
import * as AIOps from "./AIOps/index.ts";
import * as AMP from "./AMP/index.ts";
import * as Amplify from "./Amplify/index.ts";
import * as ApiGateway from "./ApiGateway/index.ts";
import * as ApiGatewayV2 from "./ApiGatewayV2/index.ts";
import * as AppConfig from "./AppConfig/index.ts";
import * as AppFlow from "./AppFlow/index.ts";
import * as AppIntegrations from "./AppIntegrations/index.ts";
import * as ApplicationAutoScaling from "./ApplicationAutoScaling/index.ts";
import * as ApplicationSignals from "./ApplicationSignals/index.ts";
import * as AppRegistry from "./AppRegistry/index.ts";
import * as AppRunner from "./AppRunner/index.ts";
import * as AppSync from "./AppSync/index.ts";
import * as Assets from "./Assets.ts";
import * as Athena from "./Athena/index.ts";
import * as AuditManager from "./AuditManager/index.ts";
import { AwsAuth } from "./AuthProvider.ts";
import * as AutoScaling from "./AutoScaling/index.ts";
import * as B2BI from "./B2BI/index.ts";
import * as Backup from "./Backup/index.ts";
import * as BackupSearch from "./BackupSearch/index.ts";
import * as Batch from "./Batch/index.ts";
import * as BCMDataExports from "./BCMDataExports/index.ts";
import * as Bedrock from "./Bedrock/index.ts";
import * as BedrockAgentCore from "./BedrockAgentCore/index.ts";
import * as BedrockDataAutomation from "./BedrockDataAutomation/index.ts";
import * as Budgets from "./Budgets/index.ts";
import * as Chatbot from "./Chatbot/index.ts";
import * as CloudControl from "./CloudControl/index.ts";
import * as CloudFormation from "./CloudFormation/index.ts";
import * as CloudFront from "./CloudFront/index.ts";
import * as CloudHSMV2 from "./CloudHSMV2/index.ts";
import * as CloudMap from "./CloudMap/index.ts";
import * as CloudTrail from "./CloudTrail/index.ts";
import * as CloudWatch from "./CloudWatch/index.ts";
import * as CodeArtifact from "./CodeArtifact/index.ts";
import * as CodeBuild from "./CodeBuild/index.ts";
import * as CodeConnections from "./CodeConnections/index.ts";
import * as CodeDeploy from "./CodeDeploy/index.ts";
import * as CodePipeline from "./CodePipeline/index.ts";
import * as Cognito from "./Cognito/index.ts";
import * as Config from "./Config/index.ts";
import * as ControlTower from "./ControlTower/index.ts";
import * as CostAndUsageReport from "./CostAndUsageReport/index.ts";
import * as CostExplorer from "./CostExplorer/index.ts";
import * as Credentials from "./Credentials.ts";
import * as DataBrew from "./DataBrew/index.ts";
import * as DataExchange from "./DataExchange/index.ts";
import * as DataSync from "./DataSync/index.ts";
import * as DataZone from "./DataZone/index.ts";
import * as DAX from "./DAX/index.ts";
import * as Deadline from "./Deadline/index.ts";
import * as Detective from "./Detective/index.ts";
import * as DevOpsGuru from "./DevOpsGuru/index.ts";
import * as DirectoryService from "./DirectoryService/index.ts";
import * as DLM from "./DLM/index.ts";
import * as DMS from "./DMS/index.ts";
import * as DocDB from "./DocDB/index.ts";
import * as DocDBElastic from "./DocDBElastic/index.ts";
import * as DSQL from "./DSQL/index.ts";
import * as DynamoDB from "./DynamoDB/index.ts";
import * as EC2 from "./EC2/index.ts";
import * as ECR from "./ECR/index.ts";
import * as ECRPublic from "./ECRPublic/index.ts";
import * as ECS from "./ECS/index.ts";
import * as EFS from "./EFS/index.ts";
import * as EKS from "./EKS/index.ts";
import * as ElastiCache from "./ElastiCache/index.ts";
import * as ELBv2 from "./ELBv2/index.ts";
import * as EMR from "./EMR/index.ts";
import * as EMRContainers from "./EMRContainers/index.ts";
import * as EMRServerless from "./EMRServerless/index.ts";
import * as Endpoint from "./Endpoint.ts";
import * as EntityResolution from "./EntityResolution/index.ts";
import { providedOrDefault } from "./Environment.ts";
import * as EventBridge from "./EventBridge/index.ts";
import * as FinSpace from "./FinSpace/index.ts";
import * as Firehose from "./Firehose/index.ts";
import * as FIS from "./FIS/index.ts";
import * as FMS from "./FMS/index.ts";
import * as Forecast from "./Forecast/index.ts";
import * as FraudDetector from "./FraudDetector/index.ts";
import * as FSx from "./FSx/index.ts";
import * as Glacier from "./Glacier/index.ts";
import * as GlobalAccelerator from "./GlobalAccelerator/index.ts";
import * as Glue from "./Glue/index.ts";
import * as Grafana from "./Grafana/index.ts";
import * as GreengrassV2 from "./GreengrassV2/index.ts";
import * as GuardDuty from "./GuardDuty/index.ts";
import * as HealthLake from "./HealthLake/index.ts";
import * as IAM from "./IAM/index.ts";
import * as IdentityCenter from "./IdentityCenter/index.ts";
import * as ImageBuilder from "./ImageBuilder/index.ts";
import * as Inspector2 from "./Inspector2/index.ts";
import * as InternetMonitor from "./InternetMonitor/index.ts";
import * as IoT from "./IoT/index.ts";
import * as IoTFleetWise from "./IoTFleetWise/index.ts";
import * as IoTManagedIntegrations from "./IoTManagedIntegrations/index.ts";
import * as IoTSiteWise from "./IoTSiteWise/index.ts";
import * as IoTWireless from "./IoTWireless/index.ts";
import * as IVS from "./IVS/index.ts";
import * as IVSChat from "./IVSChat/index.ts";
import * as IVSRealtime from "./IVSRealtime/index.ts";
import * as Kafka from "./Kafka/index.ts";
import * as Kendra from "./Kendra/index.ts";
import * as Keyspaces from "./Keyspaces/index.ts";
import * as Kinesis from "./Kinesis/index.ts";
import * as KinesisAnalyticsV2 from "./KinesisAnalyticsV2/index.ts";
import * as KinesisVideo from "./KinesisVideo/index.ts";
import * as KMS from "./KMS/index.ts";
import * as LakeFormation from "./LakeFormation/index.ts";
import * as Lambda from "./Lambda/index.ts";
import * as LexV2 from "./LexV2/index.ts";
import * as LicenseManager from "./LicenseManager/index.ts";
import { flociDual, flociServices } from "./Local/FlociServices.ts";
import { captureAwsEnvironment, pinCollectionEnvironment } from "./Local/ProviderContext.ts";
import * as Location from "./Location/index.ts";
import * as Logs from "./Logs/index.ts";
import * as Macie2 from "./Macie2/index.ts";
import * as MailManager from "./MailManager/index.ts";
import * as MediaConnect from "./MediaConnect/index.ts";
import * as MediaConvert from "./MediaConvert/index.ts";
import * as MediaLive from "./MediaLive/index.ts";
import * as MediaPackageV2 from "./MediaPackageV2/index.ts";
import * as MediaTailor from "./MediaTailor/index.ts";
import * as MedicalImaging from "./MedicalImaging/index.ts";
import * as MemoryDB from "./MemoryDB/index.ts";
import * as MQ from "./MQ/index.ts";
import * as MWAA from "./MWAA/index.ts";
import * as MWAAServerless from "./MWAAServerless/index.ts";
import * as Neptune from "./Neptune/index.ts";
import * as NeptuneGraph from "./NeptuneGraph/index.ts";
import * as NetworkFirewall from "./NetworkFirewall/index.ts";
import * as Notifications from "./Notifications/index.ts";
import * as NotificationsContacts from "./NotificationsContacts/index.ts";
import * as OAM from "./OAM/index.ts";
import * as ObservabilityAdmin from "./ObservabilityAdmin/index.ts";
import * as Omics from "./Omics/index.ts";
import * as OpenSearch from "./OpenSearch/index.ts";
import * as OpenSearchServerless from "./OpenSearchServerless/index.ts";
import * as Organizations from "./Organizations/index.ts";
import * as OSIS from "./OSIS/index.ts";
import * as PaymentCryptography from "./PaymentCryptography/index.ts";
import * as Personalize from "./Personalize/index.ts";
import * as PinpointSMSVoiceV2 from "./PinpointSMSVoiceV2/index.ts";
import * as Pipes from "./Pipes/index.ts";
import * as Polly from "./Polly/index.ts";
import * as QApps from "./QApps/index.ts";
import * as QBusiness from "./QBusiness/index.ts";
import * as QuickSight from "./QuickSight/index.ts";
import * as RAM from "./RAM/index.ts";
import * as Rbin from "./Rbin/index.ts";
import * as RDS from "./RDS/index.ts";
import * as Redshift from "./Redshift/index.ts";
import * as RedshiftServerless from "./RedshiftServerless/index.ts";
import * as Region from "./Region.ts";
import * as RePostSpace from "./RePostSpace/index.ts";
import * as ResourceExplorer from "./ResourceExplorer/index.ts";
import * as ResourceGroups from "./ResourceGroups/index.ts";
import * as RolesAnywhere from "./RolesAnywhere/index.ts";
import * as Route53 from "./Route53/index.ts";
import * as Route53Profiles from "./Route53Profiles/index.ts";
import * as Route53Resolver from "./Route53Resolver/index.ts";
import * as RUM from "./RUM/index.ts";
import * as S3 from "./S3/index.ts";
import * as S3Control from "./S3Control/index.ts";
import * as S3Files from "./S3Files/index.ts";
import * as S3Tables from "./S3Tables/index.ts";
import * as S3Vectors from "./S3Vectors/index.ts";
import * as SageMaker from "./SageMaker/index.ts";
import * as Scheduler from "./Scheduler/index.ts";
import * as Schemas from "./Schemas/index.ts";
import * as SecretsManager from "./SecretsManager/index.ts";
import * as SecurityHub from "./SecurityHub/index.ts";
import * as SecurityLake from "./SecurityLake/index.ts";
import * as ServiceCatalog from "./ServiceCatalog/index.ts";
import * as ServiceQuotas from "./ServiceQuotas/index.ts";
import * as SES from "./SES/index.ts";
import * as Shield from "./Shield/index.ts";
import * as Signer from "./Signer/index.ts";
import * as SimpleDB from "./SimpleDB/index.ts";
import * as SNS from "./SNS/index.ts";
import * as SocialMessaging from "./SocialMessaging/index.ts";
import * as SQS from "./SQS/index.ts";
import * as SSM from "./SSM/index.ts";
import * as SSMContacts from "./SSMContacts/index.ts";
import * as SSMIncidents from "./SSMIncidents/index.ts";
import * as StepFunctions from "./StepFunctions/index.ts";
import * as Synthetics from "./Synthetics/index.ts";
import * as Textract from "./Textract/index.ts";
import * as Timestream from "./Timestream/index.ts";
import * as Transfer from "./Transfer/index.ts";
import * as Translate from "./Translate/index.ts";
import * as VerifiedPermissions from "./VerifiedPermissions/index.ts";
import * as VpcLattice from "./VpcLattice/index.ts";
import * as WAFv2 from "./WAFv2/index.ts";
import * as Website from "./Website/index.ts";
import * as XRay from "./XRay/index.ts";

export class Providers extends Provider.ProviderCollection<Providers>()("AWS") {}

/**
 * Every AWS provider, pinned to one AWS environment (account, region and
 * credentials).
 *
 * By default the environment resolves lazily from the configured profile, CI
 * credentials or the ambient AWS environment. Provide your own
 * `AWSEnvironment` to deploy with another credential source, e.g. a role
 * assumed at runtime; provide the same layer to {@link state} so resources and
 * state share it.
 *
 * ```typescript
 * const environment = Layer.effect(
 *   AWS.AWSEnvironment,
 *   Effect.gen(function* () {
 *     const session = yield* assumeDeployRole;
 *     return Effect.succeed({
 *       accountId: session.accountId,
 *       region: session.region,
 *       credentials: session.credentials,
 *     });
 *   }),
 * );
 *
 * const Stack = Alchemy.Stack(
 *   "my-stack",
 *   {
 *     providers: AWS.providers().pipe(Layer.provide(environment)),
 *     state: AWS.state({ bucketName: "my-company-state" }).pipe(Layer.provide(environment)),
 *   },
 *   program,
 * );
 * ```
 */
export const providers = () =>
  Layer.effect(
    Providers,
    // Providers are PINNED to the environment they are registered with (the
    // live chain provided at the bottom of this pipe) — see
    // `pinCollectionEnvironment`. The ambient environment the STACK program
    // sees flips to the emulator in a dev run (bottom of this file), and the
    // pin is what keeps live-mode and mode-agnostic providers on the real
    // cloud regardless.
    Effect.flatMap(
      Provider.collection([
        KeyPair,
        Random,
        AccessAnalyzer.Analyzer,
        AccessAnalyzer.ArchiveRule,
        Account.AccountName,
        Account.AlternateContact,
        Account.ContactInformation,
        Account.Region,
        ACM.AccountConfiguration,
        ACM.Certificate,
        ACMPCA.CertificateAuthority,
        ACMPCA.CertificateAuthorityPolicy,
        ACMPCA.Permission,
        AIOps.InvestigationGroup,
        AMP.AlertManagerDefinition,
        AMP.AnomalyDetector,
        AMP.LoggingConfiguration,
        AMP.QueryLoggingConfiguration,
        AMP.ResourcePolicy,
        AMP.RuleGroupsNamespace,
        AMP.Scraper,
        AMP.ScraperLoggingConfiguration,
        AMP.Workspace,
        Amplify.App,
        Amplify.Branch,
        ApiGateway.Account,
        ApiGateway.ApiKey,
        ApiGateway.Authorizer,
        ApiGateway.BasePathMapping,
        ApiGateway.DeploymentResource,
        ApiGateway.DomainName,
        ApiGateway.GatewayResponse,
        ApiGateway.MethodResource,
        ApiGateway.GatewayResource,
        ApiGateway.RestApi,
        ApiGateway.StageResource,
        ApiGateway.UsagePlan,
        ApiGateway.UsagePlanKey,
        ApiGateway.VpcLink,
        ApiGatewayV2.Api,
        ApiGatewayV2.ApiMappingResource,
        ApiGatewayV2.AuthorizerResource,
        ApiGatewayV2.DomainName,
        ApiGatewayV2.IntegrationResource,
        ApiGatewayV2.RouteResource,
        ApiGatewayV2.StageResource,
        ApiGatewayV2.VpcLink,
        AppConfig.Application,
        AppConfig.ConfigurationProfile,
        AppConfig.Deployment,
        AppConfig.DeploymentStrategy,
        AppConfig.Environment,
        AppConfig.Extension,
        AppConfig.ExtensionAssociation,
        AppConfig.HostedConfigurationVersion,
        AppFlow.ConnectorProfile,
        AppFlow.Flow,
        AppIntegrations.Application,
        AppIntegrations.DataIntegration,
        AppIntegrations.EventIntegration,
        ApplicationAutoScaling.ScalableTarget,
        ApplicationAutoScaling.ScalingPolicy,
        ApplicationAutoScaling.ScheduledAction,
        ApplicationSignals.Discovery,
        ApplicationSignals.GroupingConfiguration,
        ApplicationSignals.InstrumentationConfiguration,
        ApplicationSignals.ServiceLevelObjective,
        AppRegistry.Application,
        AppRegistry.AttributeGroup,
        AppRegistry.AttributeGroupAssociation,
        AppRegistry.ResourceAssociation,
        AppRunner.AutoScalingConfiguration,
        AppRunner.ObservabilityConfiguration,
        AppRunner.Service,
        AppRunner.VpcConnector,
        AppSync.ApiAssociationResource,
        AppSync.ApiKeyResource,
        AppSync.DataSourceResource,
        AppSync.DomainName,
        AppSync.FunctionResource,
        AppSync.GraphqlApi,
        AppSync.ResolverResource,
        Athena.DataCatalog,
        Athena.NamedQuery,
        Athena.PreparedStatement,
        Athena.WorkGroup,
        AuditManager.Assessment,
        AuditManager.Control,
        AuditManager.Framework,
        AutoScaling.AutoScalingGroup,
        AutoScaling.LaunchTemplate,
        AutoScaling.LifecycleHook,
        AutoScaling.ScalingPolicy,
        AutoScaling.ScheduledAction,
        B2BI.Capability,
        B2BI.Partnership,
        B2BI.Profile,
        B2BI.Transformer,
        Backup.BackupPlan,
        Backup.BackupSelection,
        Backup.BackupVault,
        BackupSearch.ExportJob,
        BackupSearch.SearchJob,
        Batch.ComputeEnvironment,
        Batch.JobDefinition,
        Batch.JobQueue,
        BCMDataExports.Export,
        Bedrock.Agent,
        Bedrock.AgentAlias,
        Bedrock.DataSource,
        Bedrock.KnowledgeBase,
        BedrockAgentCore.BrowserCustom,
        BedrockAgentCore.CodeInterpreter,
        BedrockAgentCore.Gateway,
        BedrockAgentCore.Memory,
        BedrockAgentCore.Runtime,
        BedrockDataAutomation.Blueprint,
        BedrockDataAutomation.DataAutomationLibrary,
        BedrockDataAutomation.DataAutomationProject,
        Budgets.Budget,
        Budgets.BudgetAction,
        Chatbot.Association,
        Chatbot.CustomAction,
        Chatbot.MicrosoftTeamsChannelConfiguration,
        Chatbot.SlackChannelConfiguration,
        CloudControl.Resource,
        CloudFormation.Stack,
        CloudFront.CachePolicy,
        CloudFront.Distribution,
        CloudFront.Function,
        CloudFront.Invalidation,
        CloudFront.KeyGroup,
        CloudFront.KeyValueStore,
        CloudFront.KvEntries,
        CloudFront.KvRoutesUpdate,
        CloudFront.OriginAccessControl,
        CloudFront.OriginRequestPolicy,
        CloudFront.PublicKey,
        CloudFront.RealtimeLogConfig,
        CloudFront.ResponseHeadersPolicy,
        CloudFront.VpcOrigin,
        CloudHSMV2.Cluster,
        CloudHSMV2.Hsm,
        CloudMap.HttpNamespace,
        CloudMap.InstanceRegistration,
        CloudMap.PrivateDnsNamespace,
        CloudMap.PublicDnsNamespace,
        CloudMap.Service,
        CloudTrail.EventDataStore,
        CloudTrail.Trail,
        CloudWatch.Alarm,
        CloudWatch.AlarmMuteRule,
        CloudWatch.AnomalyDetector,
        CloudWatch.CompositeAlarm,
        CloudWatch.Dashboard,
        CloudWatch.InsightRule,
        CloudWatch.MetricStream,
        CodeArtifact.Domain,
        CodeArtifact.Repository,
        CodeBuild.Project,
        CodeBuild.ReportGroup,
        CodeConnections.Connection,
        CodeConnections.Host,
        CodeConnections.RepositoryLink,
        CodeConnections.SyncConfiguration,
        CodeDeploy.Application,
        CodeDeploy.DeploymentConfig,
        CodeDeploy.DeploymentGroup,
        CodePipeline.Pipeline,
        Cognito.Group,
        Cognito.IdentityPool,
        Cognito.IdentityPoolRoleAttachment,
        Cognito.IdentityProvider,
        Cognito.ManagedLoginBranding,
        Cognito.ResourceServer,
        Cognito.User,
        Cognito.UserPool,
        Cognito.UserPoolClient,
        Cognito.UserPoolDomain,
        Config.AggregationAuthorization,
        Config.ConfigRule,
        Config.ConfigurationRecorder,
        Config.DeliveryChannel,
        Config.RetentionConfiguration,
        ControlTower.EnabledBaseline,
        ControlTower.EnabledControl,
        ControlTower.LandingZone,
        CostAndUsageReport.ReportDefinition,
        CostExplorer.AnomalyMonitor,
        CostExplorer.AnomalySubscription,
        CostExplorer.CostCategory,
        DataBrew.Dataset,
        DataBrew.Job,
        DataBrew.Project,
        DataBrew.Recipe,
        DataBrew.Ruleset,
        DataBrew.Schedule,
        DataExchange.DataSet,
        DataExchange.EventAction,
        DataExchange.Revision,
        DataSync.LocationEfs,
        DataSync.LocationS3,
        DataSync.Task,
        DataZone.Domain,
        DataZone.Environment,
        DataZone.EnvironmentBlueprintConfiguration,
        DataZone.Project,
        DAX.Cluster,
        DAX.ParameterGroup,
        DAX.SubnetGroup,
        Deadline.Budget,
        Deadline.Farm,
        Deadline.Fleet,
        Deadline.Monitor,
        Deadline.Queue,
        Deadline.StorageProfile,
        DirectoryService.ConditionalForwarder,
        DirectoryService.Directory,
        DirectoryService.EventTopic,
        DLM.LifecyclePolicy,
        DocDB.DBCluster,
        DocDB.DBInstance,
        DocDB.DBSubnetGroup,
        DocDBElastic.Cluster,
        DMS.Endpoint,
        DMS.ReplicationInstance,
        DMS.ReplicationSubnetGroup,
        DSQL.Cluster,
        DSQL.ClusterPolicy,
        DSQL.Stream,
        Detective.Graph,
        DevOpsGuru.EventSourcesConfig,
        DevOpsGuru.NotificationChannel,
        DevOpsGuru.ResourceCollection,
        DevOpsGuru.ServiceIntegration,
        DynamoDB.Table,
        EC2.DhcpOptions,
        EC2.EgressOnlyInternetGateway,
        EC2.EIP,
        EC2.FlowLog,
        EC2.Instance,
        EC2.InternetGateway,
        EC2.KeyPair,
        EC2.NatGateway,
        EC2.NetworkAcl,
        EC2.NetworkAclAssociation,
        EC2.NetworkAclEntry,
        EC2.NetworkInterface,
        EC2.NetworkInterfaceAttachment,
        EC2.PrefixList,
        EC2.Route,
        EC2.RouteTable,
        EC2.RouteTableAssociation,
        EC2.SecurityGroup,
        EC2.DefaultSecurityGroup,
        EC2.SecurityGroupRule,
        EC2.Snapshot,
        EC2.Subnet,
        EC2.Volume,
        EC2.VolumeAttachment,
        EC2.ClientVpnEndpoint,
        EC2.ClientVpnTargetNetworkAssociation,
        EC2.ClientVpnAuthorizationRule,
        EC2.ClientVpnRoute,
        EC2.Vpc,
        EC2.VpcEndpoint,
        EC2.VpcPeeringConnection,
        ECR.Image,
        ECR.RegistryPolicy,
        ECR.Repository,
        ECRPublic.PublicRepository,
        ECS.CapacityProvider,
        ECS.Cluster,
        ECS.Service,
        ECS.Task,
        ECS.TaskDefinition,
        EFS.AccessPoint,
        EFS.FileSystem,
        EFS.MountTarget,
        EKS.AccessEntry,
        EKS.Addon,
        EKS.Cluster,
        EKS.FargateProfile,
        EKS.Nodegroup,
        EKS.PodIdentityAssociation,
        ElastiCache.CacheCluster,
        ElastiCache.ReplicationGroup,
        ElastiCache.ServerlessCache,
        ElastiCache.SubnetGroup,
        ELBv2.Listener,
        ELBv2.ListenerCertificate,
        ELBv2.ListenerRule,
        ELBv2.LoadBalancer,
        ELBv2.TargetGroup,
        ELBv2.TargetGroupAttachment,
        ELBv2.TrustStore,
        EMR.Cluster,
        EMR.SecurityConfiguration,
        EMR.Studio,
        EMRContainers.JobTemplate,
        EMRContainers.VirtualCluster,
        EMRServerless.Application,
        EntityResolution.IdMappingWorkflow,
        EntityResolution.IdNamespace,
        EntityResolution.MatchingWorkflow,
        EntityResolution.SchemaMapping,
        EventBridge.ApiDestination,
        EventBridge.Archive,
        EventBridge.Connection,
        EventBridge.EventBus,
        EventBridge.Permission,
        EventBridge.Rule,
        FIS.ExperimentTemplate,
        FIS.TargetAccountConfiguration,
        FMS.AdminAccount,
        FinSpace.Environment,
        FinSpace.KxCluster,
        FinSpace.KxDatabase,
        FinSpace.KxEnvironment,
        Firehose.DeliveryStream,
        FSx.FileSystem,
        Forecast.Dataset,
        Forecast.DatasetGroup,
        FraudDetector.Detector,
        FraudDetector.DetectorVersion,
        FraudDetector.EntityType,
        FraudDetector.EventType,
        FraudDetector.Label,
        FraudDetector.List,
        FraudDetector.Outcome,
        FraudDetector.Variable,
        Glacier.Vault,
        GlobalAccelerator.Accelerator,
        GlobalAccelerator.EndpointGroup,
        GlobalAccelerator.Listener,
        Glue.Connection,
        Glue.Crawler,
        Glue.Database,
        Glue.Job,
        Glue.Table,
        Grafana.Workspace,
        GreengrassV2.ComponentVersion,
        GreengrassV2.Deployment,
        GuardDuty.Detector,
        GuardDuty.Filter,
        GuardDuty.IPSet,
        GuardDuty.ThreatIntelSet,
        HealthLake.FHIRDatastore,
        IAM.AccessKey,
        IAM.AccountAlias,
        IAM.AccountPasswordPolicy,
        IAM.Group,
        IAM.GroupMembership,
        IAM.InstanceProfile,
        IAM.LoginProfile,
        IAM.OpenIDConnectProvider,
        IAM.Policy,
        IAM.Role,
        IAM.SAMLProvider,
        IAM.ServerCertificate,
        IAM.ServiceLinkedRole,
        IAM.ServiceSpecificCredential,
        IAM.SigningCertificate,
        IAM.SSHPublicKey,
        IAM.User,
        IAM.VirtualMFADevice,
        IdentityCenter.AccountAssignment,
        IdentityCenter.Group,
        IdentityCenter.Instance,
        ImageBuilder.Component,
        ImageBuilder.DistributionConfiguration,
        ImageBuilder.ImagePipeline,
        ImageBuilder.ImageRecipe,
        ImageBuilder.InfrastructureConfiguration,
        Inspector2.CisScanConfiguration,
        Inspector2.Enabler,
        Inspector2.Filter,
        InternetMonitor.Monitor,
        IdentityCenter.PermissionSet,
        IoT.Policy,
        IoT.Thing,
        IoT.ThingType,
        IoT.TopicRule,
        IoTFleetWise.Campaign,
        IoTFleetWise.DecoderManifest,
        IoTFleetWise.Fleet,
        IoTFleetWise.ModelManifest,
        IoTFleetWise.SignalCatalog,
        IoTFleetWise.StateTemplate,
        IoTFleetWise.Vehicle,
        IoTManagedIntegrations.CredentialLocker,
        IoTManagedIntegrations.Destination,
        IoTManagedIntegrations.ManagedThing,
        IoTManagedIntegrations.NotificationConfiguration,
        IoTSiteWise.Asset,
        IoTSiteWise.AssetModel,
        IoTSiteWise.Gateway,
        IoTWireless.Destination,
        IoTWireless.DeviceProfile,
        IoTWireless.ServiceProfile,
        IoTWireless.WirelessDevice,
        IoTWireless.WirelessGateway,
        IVS.Channel,
        IVS.PlaybackKeyPair,
        IVS.PlaybackRestrictionPolicy,
        IVS.RecordingConfiguration,
        IVS.StreamKey,
        IVSChat.LoggingConfiguration,
        IVSChat.Room,
        IVSRealtime.Stage,
        Kafka.ServerlessCluster,
        Kendra.DataSource,
        Kendra.Index,
        Keyspaces.Keyspace,
        Keyspaces.Table,
        Keyspaces.Type,
        KMS.Alias,
        KMS.Key,
        Kinesis.Stream,
        Kinesis.StreamConsumer,
        KinesisAnalyticsV2.Application,
        KinesisAnalyticsV2.ApplicationCloudWatchLoggingOption,
        KinesisAnalyticsV2.ApplicationSnapshot,
        KinesisVideo.SignalingChannel,
        KinesisVideo.Stream,
        LakeFormation.DataCellsFilter,
        LakeFormation.DataLakeSettings,
        LakeFormation.LFTag,
        LakeFormation.LFTagAssociation,
        LakeFormation.LFTagExpression,
        LakeFormation.OptIn,
        LakeFormation.Permissions,
        LakeFormation.Resource,
        Lambda.Alias,
        Lambda.EventSourceMapping,
        Lambda.Function,
        Lambda.LayerVersion,
        Lambda.Version,
        Lambda.MicrovmImage,
        Lambda.NetworkConnector,
        Lambda.Permission,
        Lambda.WebFunction,
        Lambda.WebFunctionEndpoint,
        Lambda.WebFunctionPermission,
        LexV2.Bot,
        LexV2.BotAlias,
        LexV2.BotLocale,
        LexV2.BotVersion,
        LexV2.Intent,
        LexV2.SlotType,
        LicenseManager.LicenseConfiguration,
        Location.ApiKey,
        Location.GeofenceCollection,
        Location.Map,
        Location.PlaceIndex,
        Location.RouteCalculator,
        Location.Tracker,
        Location.TrackerConsumer,
        Logs.Destination,
        Logs.LogGroup,
        Logs.LogStream,
        Logs.MetricFilter,
        Logs.ResourcePolicy,
        Logs.SubscriptionFilter,
        MediaConnect.Flow,
        MediaConvert.Job,
        MediaConvert.JobTemplate,
        MediaConvert.Preset,
        MediaConvert.Queue,
        MediaLive.Channel,
        MediaLive.Input,
        MediaLive.InputSecurityGroup,
        MediaPackageV2.Channel,
        MediaPackageV2.ChannelGroup,
        MediaPackageV2.OriginEndpoint,
        MediaTailor.PlaybackConfiguration,
        MedicalImaging.Datastore,
        MQ.Broker,
        MQ.Configuration,
        MWAA.Environment,
        MWAAServerless.Workflow,
        Macie2.Session,
        Macie2.ClassificationJob,
        Macie2.AllowList,
        Macie2.CustomDataIdentifier,
        Macie2.FindingsFilter,
        MailManager.AddonInstance,
        MailManager.AddonSubscription,
        MailManager.AddressList,
        MailManager.Archive,
        MailManager.IngressPoint,
        MailManager.Relay,
        MailManager.RuleSet,
        MailManager.TrafficPolicy,
        MemoryDB.ACL,
        MemoryDB.Cluster,
        MemoryDB.ParameterGroup,
        MemoryDB.SubnetGroup,
        MemoryDB.User,
        Neptune.DBCluster,
        Neptune.DBClusterParameterGroup,
        Neptune.DBInstance,
        Neptune.DBParameterGroup,
        Neptune.DBSubnetGroup,
        NeptuneGraph.Graph,
        NetworkFirewall.Firewall,
        NetworkFirewall.FirewallPolicy,
        NetworkFirewall.LoggingConfiguration,
        NetworkFirewall.RuleGroup,
        Notifications.ChannelAssociation,
        Notifications.EventRule,
        Notifications.NotificationConfiguration,
        Notifications.NotificationHub,
        NotificationsContacts.EmailContact,
        OAM.Link,
        OAM.Sink,
        ObservabilityAdmin.TelemetryConfig,
        ObservabilityAdmin.TelemetryRule,
        Omics.AnnotationStore,
        Omics.ReferenceStore,
        Omics.RunGroup,
        Omics.SequenceStore,
        Omics.VariantStore,
        Omics.Workflow,
        OpenSearch.Domain,
        OSIS.Pipeline,
        OSIS.PipelineEndpoint,
        OSIS.ResourcePolicy,
        OpenSearchServerless.AccessPolicy,
        OpenSearchServerless.Collection,
        OpenSearchServerless.CollectionGroup,
        OpenSearchServerless.LifecyclePolicy,
        OpenSearchServerless.SecurityConfig,
        OpenSearchServerless.SecurityPolicy,
        OpenSearchServerless.VpcEndpoint,
        Organizations.Account,
        Organizations.DelegatedAdministrator,
        Organizations.Organization,
        Organizations.OrganizationalUnit,
        Organizations.OrganizationResourcePolicy,
        Organizations.Policy,
        Organizations.PolicyAttachment,
        Organizations.Root,
        Organizations.RootPolicyType,
        Organizations.TrustedServiceAccess,
        PaymentCryptography.Alias,
        PaymentCryptography.Key,
        Personalize.Dataset,
        Personalize.DatasetGroup,
        Personalize.EventTracker,
        Personalize.Schema,
        PinpointSMSVoiceV2.ConfigurationSet,
        PinpointSMSVoiceV2.EventDestination,
        PinpointSMSVoiceV2.OptOutList,
        PinpointSMSVoiceV2.PhoneNumber,
        Pipes.Pipe,
        Polly.Lexicon,
        QApps.QApp,
        QBusiness.Application,
        QBusiness.DataSource,
        QBusiness.Index,
        QBusiness.Retriever,
        QBusiness.WebExperience,
        QuickSight.Analysis,
        QuickSight.Dashboard,
        QuickSight.DataSet,
        QuickSight.DataSource,
        RAM.Permission,
        RAM.ResourceShare,
        RDS.DBCluster,
        RDS.DBClusterEndpoint,
        RDS.DBClusterParameterGroup,
        RDS.DBInstance,
        RDS.DBParameterGroup,
        RDS.DBProxy,
        RDS.DBProxyEndpoint,
        RDS.DBProxyTargetGroup,
        RDS.DBSubnetGroup,
        Rbin.Rule,
        RePostSpace.Space,
        Redshift.Cluster,
        Redshift.ClusterParameterGroup,
        Redshift.ClusterSubnetGroup,
        Redshift.EventSubscription,
        RedshiftServerless.Namespace,
        RedshiftServerless.Workgroup,
        ResourceExplorer.Index,
        ResourceExplorer.View,
        ResourceGroups.Group,
        RolesAnywhere.Crl,
        RolesAnywhere.Profile,
        RolesAnywhere.TrustAnchor,
        Route53.HealthCheck,
        Route53.HostedZone,
        Route53.QueryLoggingConfig,
        Route53.Record,
        Route53.Records,
        Route53.VpcAssociationAuthorization,
        Route53.ZoneVpcAssociation,
        Route53Profiles.Profile,
        Route53Profiles.ProfileAssociation,
        Route53Profiles.ProfileResourceAssociation,
        Route53Resolver.ResolverEndpoint,
        Route53Resolver.ResolverRule,
        Route53Resolver.ResolverRuleAssociation,
        RUM.AppMonitor,
        RUM.MetricsDestination,
        RUM.ResourcePolicy,
        S3.Bucket,
        S3Control.AccessPoint,
        S3Control.AccessPointPolicy,
        S3Control.MultiRegionAccessPoint,
        S3Control.ObjectLambdaAccessPoint,
        S3Control.StorageLensConfiguration,
        S3Files.AccessPoint,
        S3Files.FileSystem,
        S3Tables.TableBucket,
        S3Tables.Namespace,
        S3Tables.Table,
        S3Vectors.VectorBucket,
        S3Vectors.Index,
        SageMaker.Model,
        SageMaker.EndpointConfig,
        SageMaker.Endpoint,
        SageMaker.FeatureGroup,
        SageMaker.Cluster,
        SageMaker.ClusterSchedulerConfig,
        SageMaker.ComputeQuota,
        Scheduler.Schedule,
        Scheduler.ScheduleGroup,
        Schemas.Discoverer,
        Schemas.Registry,
        Schemas.Schema,
        SecurityHub.ActionTarget,
        SecurityHub.AutomationRule,
        SecurityHub.FindingAggregator,
        SecurityHub.Hub,
        SecurityHub.Insight,
        SecurityLake.AwsLogSource,
        SecurityLake.CustomLogSource,
        SecurityLake.DataLake,
        SecurityLake.ExceptionSubscription,
        SecurityLake.Subscriber,
        SecurityLake.SubscriberNotification,
        SecretsManager.RotationSchedule,
        SecretsManager.Secret,
        ServiceCatalog.Portfolio,
        ServiceCatalog.PortfolioProductAssociation,
        ServiceCatalog.PrincipalPortfolioAssociation,
        ServiceCatalog.Product,
        ServiceQuotas.ServiceQuotaIncreaseRequest,
        SES.AccountSettings,
        SES.ActiveReceiptRuleSet,
        SES.ConfigurationSet,
        SES.ConfigurationSetEventDestination,
        SES.Contact,
        SES.ContactList,
        SES.CustomVerificationEmailTemplate,
        SES.DedicatedIpPool,
        SES.EmailIdentity,
        SES.EmailIdentityPolicy,
        SES.EmailTemplate,
        SES.MultiRegionEndpoint,
        SES.ReceiptFilter,
        SES.ReceiptRule,
        SES.ReceiptRuleSet,
        SES.Tenant,
        SES.TenantResourceAssociation,
        Shield.Protection,
        Shield.ProtectionGroup,
        Shield.Subscription,
        Signer.ProfilePermission,
        Signer.SigningProfile,
        SimpleDB.Domain,
        SNS.PlatformApplication,
        SNS.Subscription,
        SNS.Topic,
        SocialMessaging.LinkedWhatsAppBusinessAccount,
        SQS.Queue,
        SSM.Parameter,
        SSMContacts.Contact,
        SSMContacts.ContactChannel,
        SSMContacts.Plan,
        SSMContacts.Rotation,
        SSMIncidents.ReplicationSet,
        SSMIncidents.ResponsePlan,
        StepFunctions.Activity,
        StepFunctions.StateMachine,
        Synthetics.Canary,
        Synthetics.Group,
        Textract.Adapter,
        Timestream.Database,
        Timestream.DbInstance,
        Timestream.ScheduledQuery,
        Timestream.Table,
        Transfer.Server,
        Transfer.User,
        Translate.ParallelData,
        Translate.Terminology,
        VerifiedPermissions.IdentitySource,
        VerifiedPermissions.Policy,
        VerifiedPermissions.PolicyStore,
        VerifiedPermissions.PolicyStoreAlias,
        VerifiedPermissions.PolicyTemplate,
        VerifiedPermissions.Schema,
        VpcLattice.AccessLogSubscription,
        VpcLattice.AuthPolicy,
        VpcLattice.Listener,
        VpcLattice.ResourcePolicy,
        VpcLattice.Rule,
        VpcLattice.ServiceNetworkServiceAssociation,
        VpcLattice.TargetGroup,
        VpcLattice.Service,
        VpcLattice.ServiceNetwork,
        VpcLattice.ServiceNetworkVpcAssociation,
        WAFv2.IPSet,
        WAFv2.LoggingConfiguration,
        WAFv2.RegexPatternSet,
        WAFv2.RuleGroup,
        WAFv2.WebACL,
        WAFv2.WebACLAssociation,
        Website.AssetDeployment,
        WebsiteServer,
        XRay.Group,
        XRay.ResourcePolicy,
        XRay.SamplingRule,
      ]),
      (collection) =>
        Effect.map(captureAwsEnvironment, (environment) =>
          pinCollectionEnvironment(collection, environment),
        ),
    ),
  ).pipe(
    Layer.provide(
      Layer.mergeAll(
        Layer.mergeAll(
          ACMPCA.CertificateAuthorityProvider(),
          ACMPCA.CertificateAuthorityPolicyProvider(),
          ACMPCA.PermissionProvider(),
          AppFlow.ConnectorProfileProvider(),
          AppFlow.FlowProvider(),
          flociDual(AppIntegrations.Application, () => AppIntegrations.ApplicationProvider()),
          flociDual(AppIntegrations.DataIntegration, () =>
            AppIntegrations.DataIntegrationProvider(),
          ),
          flociDual(AppIntegrations.EventIntegration, () =>
            AppIntegrations.EventIntegrationProvider(),
          ),
          B2BI.CapabilityProvider(),
          B2BI.PartnershipProvider(),
          B2BI.ProfileProvider(),
          B2BI.TransformerProvider(),
          BedrockDataAutomation.BlueprintProvider(),
          BedrockDataAutomation.DataAutomationLibraryProvider(),
          BedrockDataAutomation.DataAutomationProjectProvider(),
          flociDual(Config.AggregationAuthorization, () =>
            Config.AggregationAuthorizationProvider(),
          ),
          flociDual(Config.ConfigRule, () => Config.ConfigRuleProvider()),
          flociDual(Config.ConfigurationRecorder, () => Config.ConfigurationRecorderProvider()),
          flociDual(Config.DeliveryChannel, () => Config.DeliveryChannelProvider()),
          flociDual(Config.RetentionConfiguration, () => Config.RetentionConfigurationProvider()),
        ),
        Layer.mergeAll(
          flociDual(ACM.AccountConfiguration, () => ACM.AccountConfigurationProvider()),
          flociDual(ACM.Certificate, () => ACM.CertificateProvider()),
          flociDual(AMP.AlertManagerDefinition, () => AMP.AlertManagerDefinitionProvider()),
          flociDual(AMP.AnomalyDetector, () => AMP.AnomalyDetectorProvider()),
          flociDual(AMP.LoggingConfiguration, () => AMP.LoggingConfigurationProvider()),
          flociDual(AMP.QueryLoggingConfiguration, () => AMP.QueryLoggingConfigurationProvider()),
          flociDual(AMP.ResourcePolicy, () => AMP.ResourcePolicyProvider()),
          flociDual(AMP.RuleGroupsNamespace, () => AMP.RuleGroupsNamespaceProvider()),
          flociDual(AMP.Scraper, () => AMP.ScraperProvider()),
          flociDual(AMP.ScraperLoggingConfiguration, () =>
            AMP.ScraperLoggingConfigurationProvider(),
          ),
          flociDual(AMP.Workspace, () => AMP.WorkspaceProvider()),
          flociDual(ApiGateway.Account, () => ApiGateway.AccountProvider()),
          flociDual(ApiGateway.ApiKey, () => ApiGateway.ApiKeyProvider()),
          flociDual(ApiGateway.Authorizer, () => ApiGateway.AuthorizerProvider()),
          flociDual(ApiGateway.BasePathMapping, () => ApiGateway.BasePathMappingProvider()),
          flociDual(ApiGateway.DeploymentResource, () => ApiGateway.DeploymentProvider()),
          flociDual(ApiGateway.DomainName, () => ApiGateway.DomainNameProvider()),
          flociDual(ApiGateway.GatewayResponse, () => ApiGateway.GatewayResponseProvider()),
          flociDual(ApiGateway.MethodResource, () => ApiGateway.MethodProvider()),
          flociDual(ApiGateway.GatewayResource, () => ApiGateway.ResourceProvider()),
          flociDual(ApiGateway.RestApi, () => ApiGateway.RestApiProvider()),
          flociDual(ApiGateway.StageResource, () => ApiGateway.StageProvider()),
          flociDual(ApiGateway.UsagePlan, () => ApiGateway.UsagePlanProvider()),
          flociDual(ApiGateway.UsagePlanKey, () => ApiGateway.UsagePlanKeyProvider()),
          flociDual(ApiGateway.VpcLink, () => ApiGateway.VpcLinkProvider()),
          flociDual(ApiGatewayV2.Api, () => ApiGatewayV2.ApiProvider()),
          flociDual(ApiGatewayV2.ApiMappingResource, () => ApiGatewayV2.ApiMappingProvider()),
          flociDual(ApiGatewayV2.AuthorizerResource, () => ApiGatewayV2.AuthorizerProvider()),
          flociDual(ApiGatewayV2.DomainName, () => ApiGatewayV2.DomainNameProvider()),
          flociDual(ApiGatewayV2.IntegrationResource, () => ApiGatewayV2.IntegrationProvider()),
          flociDual(ApiGatewayV2.RouteResource, () => ApiGatewayV2.RouteProvider()),
          flociDual(ApiGatewayV2.StageResource, () => ApiGatewayV2.StageProvider()),
          flociDual(ApiGatewayV2.VpcLink, () => ApiGatewayV2.VpcLinkProvider()),
          flociDual(AppConfig.Application, () => AppConfig.ApplicationProvider()),
          flociDual(AppConfig.ConfigurationProfile, () => AppConfig.ConfigurationProfileProvider()),
          flociDual(AppConfig.Deployment, () => AppConfig.DeploymentProvider()),
          flociDual(AppConfig.DeploymentStrategy, () => AppConfig.DeploymentStrategyProvider()),
          flociDual(AppConfig.Environment, () => AppConfig.EnvironmentProvider()),
          flociDual(AppConfig.Extension, () => AppConfig.ExtensionProvider()),
          flociDual(AppConfig.ExtensionAssociation, () => AppConfig.ExtensionAssociationProvider()),
          flociDual(AppConfig.HostedConfigurationVersion, () =>
            AppConfig.HostedConfigurationVersionProvider(),
          ),
          flociDual(ApplicationAutoScaling.ScalableTarget, () =>
            ApplicationAutoScaling.ScalableTargetProvider(),
          ),
          flociDual(ApplicationAutoScaling.ScalingPolicy, () =>
            ApplicationAutoScaling.ScalingPolicyProvider(),
          ),
          flociDual(ApplicationAutoScaling.ScheduledAction, () =>
            ApplicationAutoScaling.ScheduledActionProvider(),
          ),
          AppRunner.AutoScalingConfigurationProvider(),
          AppRunner.ObservabilityConfigurationProvider(),
          AppRunner.ServiceProvider(),
          AppRunner.VpcConnectorProvider(),
          flociDual(AppSync.ApiAssociationResource, () => AppSync.ApiAssociationProvider()),
          flociDual(AppSync.ApiKeyResource, () => AppSync.ApiKeyProvider()),
          flociDual(AppSync.DataSourceResource, () => AppSync.DataSourceProvider()),
          flociDual(AppSync.DomainName, () => AppSync.DomainNameProvider()),
          flociDual(AppSync.FunctionResource, () => AppSync.FunctionProvider()),
          flociDual(AppSync.GraphqlApi, () => AppSync.GraphqlApiProvider()),
          flociDual(AppSync.ResolverResource, () => AppSync.ResolverProvider()),
          flociDual(Athena.DataCatalog, () => Athena.DataCatalogProvider()),
          flociDual(Athena.NamedQuery, () => Athena.NamedQueryProvider()),
          flociDual(Athena.PreparedStatement, () => Athena.PreparedStatementProvider()),
          flociDual(Athena.WorkGroup, () => Athena.WorkGroupProvider()),
          flociDual(AutoScaling.AutoScalingGroup, () => AutoScaling.AutoScalingGroupProvider()),
          flociDual(AutoScaling.LaunchTemplate, () => AutoScaling.LaunchTemplateProvider()),
          flociDual(AutoScaling.LifecycleHook, () => AutoScaling.LifecycleHookProvider()),
          flociDual(AutoScaling.ScalingPolicy, () => AutoScaling.ScalingPolicyProvider()),
          flociDual(AutoScaling.ScheduledAction, () => AutoScaling.ScheduledActionProvider()),
          flociDual(Batch.ComputeEnvironment, () => Batch.ComputeEnvironmentProvider()),
          flociDual(Batch.JobDefinition, () => Batch.JobDefinitionProvider()),
          flociDual(Batch.JobQueue, () => Batch.JobQueueProvider()),
          flociDual(CloudControl.Resource, () => CloudControl.CloudControlResourceProvider()),
          flociDual(CloudFormation.Stack, () => CloudFormation.StackProvider()),
          flociDual(CloudFront.CachePolicy, () => CloudFront.CachePolicyProvider()),
          flociDual(CloudFront.Distribution, () => CloudFront.DistributionProvider()),
          flociDual(CloudFront.Function, () => CloudFront.FunctionProvider()),
          flociDual(CloudFront.Invalidation, () => CloudFront.InvalidationProvider()),
          flociDual(CloudFront.KeyGroup, () => CloudFront.KeyGroupProvider()),
          flociDual(CloudFront.KeyValueStore, () => CloudFront.KeyValueStoreProvider()),
          flociDual(CloudFront.KvEntries, () => CloudFront.KvEntriesProvider()),
          flociDual(CloudFront.KvRoutesUpdate, () => CloudFront.KvRoutesUpdateProvider()),
          flociDual(CloudFront.OriginAccessControl, () => CloudFront.OriginAccessControlProvider()),
          flociDual(CloudFront.OriginRequestPolicy, () => CloudFront.OriginRequestPolicyProvider()),
          flociDual(CloudFront.PublicKey, () => CloudFront.PublicKeyProvider()),
          flociDual(CloudFront.RealtimeLogConfig, () => CloudFront.RealtimeLogConfigProvider()),
          flociDual(CloudFront.ResponseHeadersPolicy, () =>
            CloudFront.ResponseHeadersPolicyProvider(),
          ),
          flociDual(CloudFront.VpcOrigin, () => CloudFront.VpcOriginProvider()),
          flociDual(CloudHSMV2.Cluster, () => CloudHSMV2.ClusterProvider()),
          flociDual(CloudHSMV2.Hsm, () => CloudHSMV2.HsmProvider()),
          flociDual(CloudMap.HttpNamespace, () => CloudMap.HttpNamespaceProvider()),
          flociDual(CloudMap.InstanceRegistration, () => CloudMap.InstanceRegistrationProvider()),
          flociDual(CloudMap.PrivateDnsNamespace, () => CloudMap.PrivateDnsNamespaceProvider()),
          flociDual(CloudMap.PublicDnsNamespace, () => CloudMap.PublicDnsNamespaceProvider()),
          flociDual(CloudMap.Service, () => CloudMap.ServiceProvider()),
          flociDual(CloudWatch.AlarmMuteRule, () => CloudWatch.AlarmMuteRuleProvider()),
          flociDual(CloudWatch.Alarm, () => CloudWatch.AlarmProvider()),
          flociDual(CloudWatch.AnomalyDetector, () => CloudWatch.AnomalyDetectorProvider()),
          flociDual(CloudWatch.CompositeAlarm, () => CloudWatch.CompositeAlarmProvider()),
          flociDual(CloudWatch.Dashboard, () => CloudWatch.DashboardProvider()),
          flociDual(CloudWatch.InsightRule, () => CloudWatch.InsightRuleProvider()),
          flociDual(CloudWatch.MetricStream, () => CloudWatch.MetricStreamProvider()),
          flociDual(CodeArtifact.Domain, () => CodeArtifact.DomainProvider()),
          flociDual(CodeArtifact.Repository, () => CodeArtifact.RepositoryProvider()),
          flociDual(CodeBuild.Project, () => CodeBuild.ProjectProvider()),
          flociDual(CodeBuild.ReportGroup, () => CodeBuild.ReportGroupProvider()),
          CodeConnections.ConnectionProvider(),
          CodeConnections.HostProvider(),
          CodeConnections.RepositoryLinkProvider(),
          CodeConnections.SyncConfigurationProvider(),
          flociDual(CodeDeploy.Application, () => CodeDeploy.ApplicationProvider()),
          flociDual(CodeDeploy.DeploymentConfig, () => CodeDeploy.DeploymentConfigProvider()),
          flociDual(CodeDeploy.DeploymentGroup, () => CodeDeploy.DeploymentGroupProvider()),
          flociDual(CodePipeline.Pipeline, () => CodePipeline.PipelineProvider()),
          flociDual(Cognito.Group, () => Cognito.GroupProvider()),
          flociDual(Cognito.IdentityPool, () => Cognito.IdentityPoolProvider()),
          flociDual(Cognito.IdentityPoolRoleAttachment, () =>
            Cognito.IdentityPoolRoleAttachmentProvider(),
          ),
          flociDual(Cognito.IdentityProvider, () => Cognito.IdentityProviderProvider()),
          flociDual(Cognito.ManagedLoginBranding, () => Cognito.ManagedLoginBrandingProvider()),
          flociDual(Cognito.ResourceServer, () => Cognito.ResourceServerProvider()),
          flociDual(Cognito.UserPoolClient, () => Cognito.UserPoolClientProvider()),
          flociDual(Cognito.User, () => Cognito.UserProvider()),
          flociDual(Cognito.UserPoolDomain, () => Cognito.UserPoolDomainProvider()),
          flociDual(Cognito.UserPool, () => Cognito.UserPoolProvider()),
        ),
        Layer.mergeAll(
          DataBrew.DatasetProvider(),
          DataBrew.JobProvider(),
          DataBrew.ProjectProvider(),
          DataBrew.RecipeProvider(),
          DataBrew.RulesetProvider(),
          DataBrew.ScheduleProvider(),
          DataExchange.DataSetProvider(),
          DataExchange.EventActionProvider(),
          DataExchange.RevisionProvider(),
          flociDual(DataSync.LocationEfs, () => DataSync.LocationEfsProvider()),
          flociDual(DataSync.LocationS3, () => DataSync.LocationS3Provider()),
          flociDual(DataSync.Task, () => DataSync.TaskProvider()),
          DataZone.DomainProvider(),
          DataZone.EnvironmentProvider(),
          DataZone.EnvironmentBlueprintConfigurationProvider(),
          DataZone.ProjectProvider(),
          DAX.ClusterProvider(),
          DAX.ParameterGroupProvider(),
          DAX.SubnetGroupProvider(),
          Deadline.BudgetProvider(),
          Deadline.FarmProvider(),
          Deadline.FleetProvider(),
          Deadline.MonitorProvider(),
          Deadline.QueueProvider(),
          Deadline.StorageProfileProvider(),
          DirectoryService.ConditionalForwarderProvider(),
          DirectoryService.DirectoryProvider(),
          DirectoryService.EventTopicProvider(),
          DLM.LifecyclePolicyProvider(),
          flociDual(DocDB.DBCluster, () => DocDB.DBClusterProvider()),
          flociDual(DocDB.DBInstance, () => DocDB.DBInstanceProvider()),
          flociDual(DocDB.DBSubnetGroup, () => DocDB.DBSubnetGroupProvider()),
          DocDBElastic.ClusterProvider(),
          flociDual(DMS.Endpoint, () => DMS.EndpointProvider()),
          flociDual(DMS.ReplicationInstance, () => DMS.ReplicationInstanceProvider()),
          flociDual(DMS.ReplicationSubnetGroup, () => DMS.ReplicationSubnetGroupProvider()),
          DSQL.ClusterProvider(),
          DSQL.ClusterPolicyProvider(),
          DSQL.StreamProvider(),
          DevOpsGuru.EventSourcesConfigProvider(),
          DevOpsGuru.NotificationChannelProvider(),
          DevOpsGuru.ResourceCollectionProvider(),
          DevOpsGuru.ServiceIntegrationProvider(),
          flociDual(DynamoDB.Table, () => DynamoDB.TableProvider()),
          // Keep this service-sized group nested: a flat mergeAll here exceeds
          // Effect's variadic inference limit and silently drops tail layers.
          Layer.mergeAll(
            flociDual(EC2.ClientVpnEndpoint, () => EC2.ClientVpnEndpointProvider()),
            flociDual(EC2.ClientVpnTargetNetworkAssociation, () =>
              EC2.ClientVpnTargetNetworkAssociationProvider(),
            ),
            flociDual(EC2.ClientVpnAuthorizationRule, () =>
              EC2.ClientVpnAuthorizationRuleProvider(),
            ),
            flociDual(EC2.ClientVpnRoute, () => EC2.ClientVpnRouteProvider()),
            flociDual(EC2.DefaultSecurityGroup, () => EC2.DefaultSecurityGroupProvider()),
            flociDual(EC2.DhcpOptions, () => EC2.DhcpOptionsProvider()),
            flociDual(EC2.EgressOnlyInternetGateway, () => EC2.EgressOnlyInternetGatewayProvider()),
            flociDual(EC2.EIP, () => EC2.EIPProvider()),
            flociDual(EC2.FlowLog, () => EC2.FlowLogProvider()),
            flociDual(EC2.Instance, () => EC2.InstanceProvider()),
            // Dual EC2 networking glue: local (floci) ECS services/tasks run
            // inside an emulated VPC — a live VPC can't host local containers
            // and local target groups can't reference a live vpcId.
            flociDual(EC2.InternetGateway, () => EC2.InternetGatewayProvider()),
            flociDual(EC2.KeyPair, () => EC2.KeyPairProvider()),
            flociDual(EC2.NatGateway, () => EC2.NatGatewayProvider()),
            flociDual(EC2.NetworkAclAssociation, () => EC2.NetworkAclAssociationProvider()),
            flociDual(EC2.NetworkAclEntry, () => EC2.NetworkAclEntryProvider()),
            flociDual(EC2.NetworkAcl, () => EC2.NetworkAclProvider()),
            flociDual(EC2.NetworkInterface, () => EC2.NetworkInterfaceProvider()),
            flociDual(EC2.NetworkInterfaceAttachment, () =>
              EC2.NetworkInterfaceAttachmentProvider(),
            ),
            flociDual(EC2.PrefixList, () => EC2.PrefixListProvider()),
            flociDual(EC2.Route, () => EC2.RouteProvider()),
            flociDual(EC2.RouteTableAssociation, () => EC2.RouteTableAssociationProvider()),
            flociDual(EC2.RouteTable, () => EC2.RouteTableProvider()),
            flociDual(EC2.SecurityGroup, () => EC2.SecurityGroupProvider()),
            flociDual(EC2.SecurityGroupRule, () => EC2.SecurityGroupRuleProvider()),
            flociDual(EC2.Snapshot, () => EC2.SnapshotProvider()),
            flociDual(EC2.Subnet, () => EC2.SubnetProvider()),
            flociDual(EC2.Volume, () => EC2.VolumeProvider()),
            flociDual(EC2.VolumeAttachment, () => EC2.VolumeAttachmentProvider()),
            flociDual(EC2.VpcEndpoint, () => EC2.VpcEndpointProvider()),
            flociDual(EC2.VpcPeeringConnection, () => EC2.VpcPeeringConnectionProvider()),
            flociDual(EC2.Vpc, () => EC2.VpcProvider()),
          ),
          flociDual(ECR.Image, () => ECR.ImageProvider()),
          flociDual(ECR.RegistryPolicy, () => ECR.RegistryPolicyProvider()),
          flociDual(ECR.Repository, () => ECR.RepositoryProvider()),
          flociDual(ECS.CapacityProvider, () => ECS.CapacityProviderProvider()),
          flociDual(ECS.Cluster, () => ECS.ClusterProvider()),
          // Dual: live ECS in deploy, floci-emulated (RPC-sidecar-hosted,
          // hot-reloading real containers) in dev — see FlociServiceProvider
          // / FlociTaskProvider.
          // Hand-written floci local providers still live on the floci data
          // plane: declare it so deploy-time binding clients (Action bodies,
          // plan-time `execute`) route to the emulator — and so a binding
          // spanning a `flociDual` sibling (RunTask(cluster, task)) does not
          // see "mixed data planes". Pinned by test/AWS/LocalDataPlane.test.ts.
          ProviderLayer.dual(ECS.Service, {
            live: () => ECS.ServiceProvider(),
            local: () => ECS.FlociServiceProvider(),
            dataPlane: flociServices,
          }),
          flociDual(ECS.TaskDefinition, () => ECS.TaskDefinitionProvider()),
          ProviderLayer.dual(ECS.Task, {
            live: () => ECS.TaskProvider(),
            local: () => ECS.FlociTaskProvider(),
            dataPlane: flociServices,
          }),
          flociDual(EFS.AccessPoint, () => EFS.AccessPointProvider()),
          flociDual(EFS.FileSystem, () => EFS.FileSystemProvider()),
          flociDual(EFS.MountTarget, () => EFS.MountTargetProvider()),
          flociDual(EKS.AccessEntry, () => EKS.AccessEntryProvider()),
          flociDual(EKS.Addon, () => EKS.AddonProvider()),
          flociDual(EKS.Cluster, () => EKS.ClusterProvider()),
          flociDual(EKS.FargateProfile, () => EKS.FargateProfileProvider()),
          flociDual(EKS.Nodegroup, () => EKS.NodegroupProvider()),
          flociDual(EKS.PodIdentityAssociation, () => EKS.PodIdentityAssociationProvider()),
          flociDual(ElastiCache.CacheCluster, () => ElastiCache.CacheClusterProvider()),
          flociDual(ElastiCache.ReplicationGroup, () => ElastiCache.ReplicationGroupProvider()),
          flociDual(ElastiCache.ServerlessCache, () => ElastiCache.ServerlessCacheProvider()),
          flociDual(ElastiCache.SubnetGroup, () => ElastiCache.SubnetGroupProvider()),
          // Dual ELBv2: floci emulates ALBs with locally-resolvable DNS
          // (`*.elb.localhost.floci.io` → 127.0.0.1, host-routed on the
          // gateway port) so local ECS services are reachable behind a
          // local load balancer in dev.
          flociDual(ELBv2.Listener, () => ELBv2.ListenerProvider()),
          flociDual(ELBv2.ListenerCertificate, () => ELBv2.ListenerCertificateProvider()),
          flociDual(ELBv2.ListenerRule, () => ELBv2.ListenerRuleProvider()),
          flociDual(ELBv2.LoadBalancer, () => ELBv2.LoadBalancerProvider()),
          flociDual(ELBv2.TargetGroup, () => ELBv2.TargetGroupProvider()),
          flociDual(ELBv2.TargetGroupAttachment, () => ELBv2.TargetGroupAttachmentProvider()),
          flociDual(ELBv2.TrustStore, () => ELBv2.TrustStoreProvider()),
          flociDual(EventBridge.ApiDestination, () => EventBridge.ApiDestinationProvider()),
          flociDual(EventBridge.Archive, () => EventBridge.ArchiveProvider()),
          flociDual(EventBridge.Connection, () => EventBridge.ConnectionProvider()),
          flociDual(EventBridge.EventBus, () => EventBridge.EventBusProvider()),
          // Dual like EventBus/Rule: a live PutPermission against a
          // floci-emulated bus would fail with ResourceNotFoundException.
          flociDual(EventBridge.Permission, () => EventBridge.PermissionProvider()),
          flociDual(EventBridge.Rule, () => EventBridge.RuleProvider()),
          flociDual(FIS.ExperimentTemplate, () => FIS.ExperimentTemplateProvider()),
          flociDual(FIS.TargetAccountConfiguration, () => FIS.TargetAccountConfigurationProvider()),
          flociDual(Firehose.DeliveryStream, () => Firehose.DeliveryStreamProvider()),
          FSx.FileSystemProvider(),
          Glacier.VaultProvider(),
          flociDual(Glue.Connection, () => Glue.ConnectionProvider()),
          flociDual(Glue.Crawler, () => Glue.CrawlerProvider()),
          flociDual(Glue.Database, () => Glue.DatabaseProvider()),
          flociDual(Glue.Job, () => Glue.JobProvider()),
          flociDual(Glue.Table, () => Glue.TableProvider()),
          Grafana.WorkspaceProvider(),
          GreengrassV2.ComponentVersionProvider(),
          GreengrassV2.DeploymentProvider(),
          HealthLake.FHIRDatastoreProvider(),
          flociDual(IAM.AccessKey, () => IAM.AccessKeyProvider()),
          flociDual(IAM.AccountAlias, () => IAM.AccountAliasProvider()),
          flociDual(IAM.AccountPasswordPolicy, () => IAM.AccountPasswordPolicyProvider()),
          flociDual(IAM.GroupMembership, () => IAM.GroupMembershipProvider()),
          flociDual(IAM.Group, () => IAM.GroupProvider()),
          flociDual(IAM.InstanceProfile, () => IAM.InstanceProfileProvider()),
          flociDual(IAM.LoginProfile, () => IAM.LoginProfileProvider()),
          flociDual(IAM.OpenIDConnectProvider, () => IAM.OpenIDConnectProviderProvider()),
          flociDual(IAM.Policy, () => IAM.PolicyProvider()),
          flociDual(IAM.Role, () => IAM.RoleProvider()),
          flociDual(IAM.SAMLProvider, () => IAM.SAMLProviderProvider()),
          flociDual(IAM.ServerCertificate, () => IAM.ServerCertificateProvider()),
          flociDual(IAM.ServiceLinkedRole, () => IAM.ServiceLinkedRoleProvider()),
          flociDual(IAM.ServiceSpecificCredential, () => IAM.ServiceSpecificCredentialProvider()),
          flociDual(IAM.SigningCertificate, () => IAM.SigningCertificateProvider()),
          flociDual(IAM.SSHPublicKey, () => IAM.SSHPublicKeyProvider()),
          flociDual(IAM.User, () => IAM.UserProvider()),
          flociDual(IAM.VirtualMFADevice, () => IAM.VirtualMFADeviceProvider()),
        ),
        Layer.mergeAll(
          flociDual(IdentityCenter.AccountAssignment, () =>
            IdentityCenter.AccountAssignmentProvider(),
          ),
          flociDual(IdentityCenter.Group, () => IdentityCenter.GroupProvider()),
          flociDual(IdentityCenter.Instance, () => IdentityCenter.InstanceProvider()),
          flociDual(IdentityCenter.PermissionSet, () => IdentityCenter.PermissionSetProvider()),
          flociDual(Kafka.ServerlessCluster, () => Kafka.ServerlessClusterProvider()),
          Kendra.DataSourceProvider(),
          Kendra.IndexProvider(),
          Keyspaces.KeyspaceProvider(),
          Keyspaces.TableProvider(),
          Keyspaces.TypeProvider(),
          flociDual(KMS.Alias, () => KMS.AliasProvider()),
          flociDual(KMS.Key, () => KMS.KeyProvider()),
          flociDual(Kinesis.StreamConsumer, () => Kinesis.StreamConsumerProvider()),
          flociDual(Kinesis.Stream, () => Kinesis.StreamProvider()),
          flociDual(KinesisAnalyticsV2.Application, () => KinesisAnalyticsV2.ApplicationProvider()),
          flociDual(KinesisAnalyticsV2.ApplicationCloudWatchLoggingOption, () =>
            KinesisAnalyticsV2.ApplicationCloudWatchLoggingOptionProvider(),
          ),
          flociDual(KinesisAnalyticsV2.ApplicationSnapshot, () =>
            KinesisAnalyticsV2.ApplicationSnapshotProvider(),
          ),
          KinesisVideo.SignalingChannelProvider(),
          KinesisVideo.StreamProvider(),
          flociDual(LakeFormation.DataCellsFilter, () => LakeFormation.DataCellsFilterProvider()),
          flociDual(LakeFormation.DataLakeSettings, () => LakeFormation.DataLakeSettingsProvider()),
          flociDual(LakeFormation.LFTag, () => LakeFormation.LFTagProvider()),
          flociDual(LakeFormation.LFTagAssociation, () => LakeFormation.LFTagAssociationProvider()),
          flociDual(LakeFormation.LFTagExpression, () => LakeFormation.LFTagExpressionProvider()),
          flociDual(LakeFormation.OptIn, () => LakeFormation.OptInProvider()),
          flociDual(LakeFormation.Permissions, () => LakeFormation.PermissionsProvider()),
          flociDual(LakeFormation.Resource, () => LakeFormation.ResourceProvider()),
          flociDual(Lambda.Alias, () => Lambda.AliasProvider()),
          // Requires the alchemy floci fork ≥ 1.6.0-alchemy.2: the
          // reconciler's ownership scan calls lambda ListTags on
          // `event-source-mapping:` ARNs, which stock floci 1.6.0 rejects.
          flociDual(Lambda.EventSourceMapping, () => Lambda.EventSourceMappingProvider()),
          // Dual: live Lambda in deploy, floci-emulated (RPC-sidecar-hosted,
          // hot-reloading) Lambda in dev — see FlociFunctionProvider.
          ProviderLayer.dual(Lambda.Function, {
            live: () => Lambda.FunctionProvider(),
            local: () => Lambda.FlociFunctionProvider(),
            dataPlane: flociServices,
          }),
          flociDual(Lambda.LayerVersion, () => Lambda.LayerVersionProvider()),
          flociDual(Lambda.Version, () => Lambda.VersionProvider()),
          // Dual: dev builds the MicroVM image with a plain host-side
          // `docker build` (BuildKit layer cache against the user's real
          // sources) and hands floci a pre-built `docker://` reference —
          // see FlociMicrovmImageProvider.
          ProviderLayer.dual(Lambda.MicrovmImage, {
            live: () => Lambda.MicrovmImageProvider(),
            local: () => Lambda.FlociMicrovmImageProvider(),
            dataPlane: flociServices,
          }),
          flociDual(Lambda.NetworkConnector, () => Lambda.NetworkConnectorProvider()),
          // Dual: glue onto the (dual) Lambda Function — a live addPermission
          // against a floci function ARN fails with ResourceNotFoundException.
          flociDual(Lambda.Permission, () => Lambda.PermissionProvider()),
          // Live-only: floci does not emulate Web Functions, so `alchemy dev`
          // deploys them to AWS like any mode-agnostic provider.
          Lambda.WebFunctionProvider(),
          Lambda.WebFunctionEndpointProvider(),
          Lambda.WebFunctionPermissionProvider(),
          flociDual(Logs.Destination, () => Logs.DestinationProvider()),
          flociDual(Logs.LogGroup, () => Logs.LogGroupProvider()),
          flociDual(Logs.LogStream, () => Logs.LogStreamProvider()),
          flociDual(Logs.MetricFilter, () => Logs.MetricFilterProvider()),
          flociDual(Logs.ResourcePolicy, () => Logs.ResourcePolicyProvider()),
          flociDual(Logs.SubscriptionFilter, () => Logs.SubscriptionFilterProvider()),
          MediaConnect.FlowProvider(),
          MediaConvert.JobProvider(),
          MediaConvert.JobTemplateProvider(),
          MediaConvert.PresetProvider(),
          MediaConvert.QueueProvider(),
          MediaLive.ChannelProvider(),
          MediaLive.InputProvider(),
          MediaLive.InputSecurityGroupProvider(),
          MediaPackageV2.ChannelProvider(),
          MediaPackageV2.ChannelGroupProvider(),
          MediaPackageV2.OriginEndpointProvider(),
          MediaTailor.PlaybackConfigurationProvider(),
          MedicalImaging.DatastoreProvider(),
          flociDual(MQ.Broker, () => MQ.BrokerProvider()),
          flociDual(MQ.Configuration, () => MQ.ConfigurationProvider()),
          MailManager.AddonInstanceProvider(),
          MailManager.AddonSubscriptionProvider(),
          MailManager.AddressListProvider(),
          MailManager.ArchiveProvider(),
          MailManager.IngressPointProvider(),
          MailManager.RelayProvider(),
          MailManager.RuleSetProvider(),
          MailManager.TrafficPolicyProvider(),
          flociDual(MemoryDB.ACL, () => MemoryDB.ACLProvider()),
          flociDual(MemoryDB.Cluster, () => MemoryDB.ClusterProvider()),
          flociDual(MemoryDB.ParameterGroup, () => MemoryDB.ParameterGroupProvider()),
          flociDual(MemoryDB.SubnetGroup, () => MemoryDB.SubnetGroupProvider()),
          flociDual(MemoryDB.User, () => MemoryDB.UserProvider()),
          flociDual(Neptune.DBCluster, () => Neptune.DBClusterProvider()),
          flociDual(Neptune.DBClusterParameterGroup, () =>
            Neptune.DBClusterParameterGroupProvider(),
          ),
          flociDual(Neptune.DBInstance, () => Neptune.DBInstanceProvider()),
          flociDual(Neptune.DBParameterGroup, () => Neptune.DBParameterGroupProvider()),
          flociDual(Neptune.DBSubnetGroup, () => Neptune.DBSubnetGroupProvider()),
          NeptuneGraph.GraphProvider(),
          flociDual(OpenSearch.Domain, () => OpenSearch.DomainProvider()),
          OpenSearchServerless.AccessPolicyProvider(),
          OSIS.PipelineEndpointProvider(),
          OSIS.PipelineProvider(),
          OSIS.ResourcePolicyProvider(),
          OpenSearchServerless.CollectionProvider(),
          OpenSearchServerless.CollectionGroupProvider(),
          OpenSearchServerless.LifecyclePolicyProvider(),
          OpenSearchServerless.SecurityConfigProvider(),
          OpenSearchServerless.SecurityPolicyProvider(),
          OpenSearchServerless.VpcEndpointProvider(),
          flociDual(Organizations.Account, () => Organizations.AccountProvider()),
          flociDual(Organizations.DelegatedAdministrator, () =>
            Organizations.DelegatedAdministratorProvider(),
          ),
          flociDual(Organizations.OrganizationalUnit, () =>
            Organizations.OrganizationalUnitProvider(),
          ),
          flociDual(Organizations.Organization, () => Organizations.OrganizationProvider()),
          flociDual(Organizations.OrganizationResourcePolicy, () =>
            Organizations.OrganizationResourcePolicyProvider(),
          ),
          flociDual(Organizations.PolicyAttachment, () => Organizations.PolicyAttachmentProvider()),
          flociDual(Organizations.Policy, () => Organizations.PolicyProvider()),
          flociDual(Organizations.RootPolicyType, () => Organizations.RootPolicyTypeProvider()),
          flociDual(Organizations.Root, () => Organizations.RootProvider()),
          flociDual(Organizations.TrustedServiceAccess, () =>
            Organizations.TrustedServiceAccessProvider(),
          ),
          PaymentCryptography.AliasProvider(),
          PaymentCryptography.KeyProvider(),
          flociDual(Pipes.Pipe, () => Pipes.PipeProvider()),
          Polly.LexiconProvider(),
          QApps.QAppProvider(),
          QBusiness.ApplicationProvider(),
          QBusiness.DataSourceProvider(),
          QBusiness.IndexProvider(),
          QBusiness.RetrieverProvider(),
          QBusiness.WebExperienceProvider(),
          QuickSight.AnalysisProvider(),
          QuickSight.DashboardProvider(),
          QuickSight.DataSetProvider(),
          QuickSight.DataSourceProvider(),
          flociDual(RDS.DBClusterEndpoint, () => RDS.DBClusterEndpointProvider()),
          flociDual(RDS.DBClusterParameterGroup, () => RDS.DBClusterParameterGroupProvider()),
          flociDual(RDS.DBCluster, () => RDS.DBClusterProvider()),
          flociDual(RDS.DBInstance, () => RDS.DBInstanceProvider()),
          flociDual(RDS.DBParameterGroup, () => RDS.DBParameterGroupProvider()),
          flociDual(RDS.DBProxyEndpoint, () => RDS.DBProxyEndpointProvider()),
          flociDual(RDS.DBProxy, () => RDS.DBProxyProvider()),
          flociDual(RDS.DBProxyTargetGroup, () => RDS.DBProxyTargetGroupProvider()),
          flociDual(RDS.DBSubnetGroup, () => RDS.DBSubnetGroupProvider()),
          RePostSpace.SpaceProvider(),
          flociDual(Redshift.ClusterParameterGroup, () => Redshift.ClusterParameterGroupProvider()),
          flociDual(Redshift.Cluster, () => Redshift.ClusterProvider()),
          flociDual(Redshift.ClusterSubnetGroup, () => Redshift.ClusterSubnetGroupProvider()),
          flociDual(Redshift.EventSubscription, () => Redshift.EventSubscriptionProvider()),
          RedshiftServerless.NamespaceProvider(),
          RedshiftServerless.WorkgroupProvider(),
          flociDual(Route53.HealthCheck, () => Route53.HealthCheckProvider()),
          flociDual(Route53.HostedZone, () => Route53.HostedZoneProvider()),
          flociDual(Route53.QueryLoggingConfig, () => Route53.QueryLoggingConfigProvider()),
          flociDual(Route53.Record, () => Route53.RecordProvider()),
          flociDual(Route53.Records, () => Route53.RecordsProvider()),
          flociDual(Route53.VpcAssociationAuthorization, () =>
            Route53.VpcAssociationAuthorizationProvider(),
          ),
          flociDual(Route53.ZoneVpcAssociation, () => Route53.ZoneVpcAssociationProvider()),
          flociDual(S3.Bucket, () => S3.BucketProvider()),
          // Dual: schedules created by e.g. `AWS.ECS.every` reference local
          // cluster/task/role ARNs in dev — a live PutSchedule with a floci
          // role ARN fails validation.
          flociDual(Scheduler.ScheduleGroup, () => Scheduler.ScheduleGroupProvider()),
          flociDual(Scheduler.Schedule, () => Scheduler.ScheduleProvider()),
          flociDual(SecretsManager.RotationSchedule, () =>
            SecretsManager.RotationScheduleProvider(),
          ),
          flociDual(SecretsManager.Secret, () => SecretsManager.SecretProvider()),
          flociDual(SES.AccountSettings, () => SES.AccountSettingsProvider()),
          flociDual(SES.ActiveReceiptRuleSet, () => SES.ActiveReceiptRuleSetProvider()),
          flociDual(SES.ConfigurationSetEventDestination, () =>
            SES.ConfigurationSetEventDestinationProvider(),
          ),
          flociDual(SES.ConfigurationSet, () => SES.ConfigurationSetProvider()),
          flociDual(SES.ContactList, () => SES.ContactListProvider()),
          flociDual(SES.Contact, () => SES.ContactProvider()),
          flociDual(SES.CustomVerificationEmailTemplate, () =>
            SES.CustomVerificationEmailTemplateProvider(),
          ),
          flociDual(SES.DedicatedIpPool, () => SES.DedicatedIpPoolProvider()),
          flociDual(SES.EmailIdentity, () => SES.EmailIdentityProvider()),
          flociDual(SES.EmailIdentityPolicy, () => SES.EmailIdentityPolicyProvider()),
          flociDual(SES.EmailTemplate, () => SES.EmailTemplateProvider()),
          flociDual(SES.MultiRegionEndpoint, () => SES.MultiRegionEndpointProvider()),
          flociDual(SES.ReceiptFilter, () => SES.ReceiptFilterProvider()),
          flociDual(SES.ReceiptRule, () => SES.ReceiptRuleProvider()),
          flociDual(SES.ReceiptRuleSet, () => SES.ReceiptRuleSetProvider()),
          flociDual(SES.Tenant, () => SES.TenantProvider()),
          flociDual(SES.TenantResourceAssociation, () => SES.TenantResourceAssociationProvider()),
          flociDual(SNS.PlatformApplication, () => SNS.PlatformApplicationProvider()),
          // Dual: glue onto the (dual) SNS Topic — a live subscribe with a
          // floci topic ARN fails with InvalidParameterException: TopicArn.
          flociDual(SNS.Subscription, () => SNS.SubscriptionProvider()),
          flociDual(SNS.Topic, () => SNS.TopicProvider()),
          SocialMessaging.LinkedWhatsAppBusinessAccountProvider(),
          flociDual(SQS.Queue, () => SQS.QueueProvider()),
          flociDual(SSM.Parameter, () => SSM.ParameterProvider()),
          flociDual(StepFunctions.Activity, () => StepFunctions.ActivityProvider()),
          flociDual(StepFunctions.StateMachine, () => StepFunctions.StateMachineProvider()),
          flociDual(WAFv2.IPSet, () => WAFv2.IPSetProvider()),
          flociDual(WAFv2.LoggingConfiguration, () => WAFv2.LoggingConfigurationProvider()),
          flociDual(WAFv2.RegexPatternSet, () => WAFv2.RegexPatternSetProvider()),
          flociDual(WAFv2.RuleGroup, () => WAFv2.RuleGroupProvider()),
          flociDual(WAFv2.WebACLAssociation, () => WAFv2.WebACLAssociationProvider()),
          flociDual(WAFv2.WebACL, () => WAFv2.WebACLProvider()),
          flociDual(Website.AssetDeployment, () => Website.AssetDeploymentProvider()),
          // ServerProvider is internally dual (LocalProvider.make → ServerLocal).
          WebsiteServerProvider(),
          XRay.GroupProvider(),
          XRay.ResourcePolicyProvider(),
          XRay.SamplingRuleProvider(),
          Bedrock.AgentProvider(),
          Bedrock.AgentAliasProvider(),
          Bedrock.DataSourceProvider(),
          Bedrock.KnowledgeBaseProvider(),
          flociDual(BedrockAgentCore.BrowserCustom, () => BedrockAgentCore.BrowserCustomProvider()),
          flociDual(BedrockAgentCore.CodeInterpreter, () =>
            BedrockAgentCore.CodeInterpreterProvider(),
          ),
          flociDual(BedrockAgentCore.Gateway, () => BedrockAgentCore.GatewayProvider()),
          flociDual(BedrockAgentCore.Memory, () => BedrockAgentCore.MemoryProvider()),
          flociDual(BedrockAgentCore.Runtime, () => BedrockAgentCore.RuntimeProvider()),
          flociDual(AccessAnalyzer.Analyzer, () => AccessAnalyzer.AnalyzerProvider()),
          flociDual(AccessAnalyzer.ArchiveRule, () => AccessAnalyzer.ArchiveRuleProvider()),
          Textract.AdapterProvider(),
          flociDual(Transfer.Server, () => Transfer.ServerProvider()),
          flociDual(Transfer.User, () => Transfer.UserProvider()),
          Translate.ParallelDataProvider(),
          Translate.TerminologyProvider(),
          flociDual(VerifiedPermissions.IdentitySource, () =>
            VerifiedPermissions.IdentitySourceProvider(),
          ),
          flociDual(VerifiedPermissions.Policy, () => VerifiedPermissions.PolicyProvider()),
          flociDual(VerifiedPermissions.PolicyStore, () =>
            VerifiedPermissions.PolicyStoreProvider(),
          ),
          flociDual(VerifiedPermissions.PolicyStoreAlias, () =>
            VerifiedPermissions.PolicyStoreAliasProvider(),
          ),
          flociDual(VerifiedPermissions.PolicyTemplate, () =>
            VerifiedPermissions.PolicyTemplateProvider(),
          ),
          flociDual(VerifiedPermissions.Schema, () => VerifiedPermissions.SchemaProvider()),
          flociDual(Backup.BackupVault, () => Backup.BackupVaultProvider()),
          flociDual(Backup.BackupPlan, () => Backup.BackupPlanProvider()),
          flociDual(Backup.BackupSelection, () => Backup.BackupSelectionProvider()),
          BackupSearch.SearchJobProvider(),
          BackupSearch.ExportJobProvider(),
          flociDual(BCMDataExports.Export, () => BCMDataExports.ExportProvider()),
          flociDual(Budgets.Budget, () => Budgets.BudgetProvider()),
          flociDual(Budgets.BudgetAction, () => Budgets.BudgetActionProvider()),
          Chatbot.AssociationProvider(),
          Chatbot.CustomActionProvider(),
          Chatbot.MicrosoftTeamsChannelConfigurationProvider(),
          Chatbot.SlackChannelConfigurationProvider(),
          flociDual(GuardDuty.Detector, () => GuardDuty.DetectorProvider()),
          flociDual(GuardDuty.Filter, () => GuardDuty.FilterProvider()),
          flociDual(GuardDuty.IPSet, () => GuardDuty.IPSetProvider()),
          flociDual(GuardDuty.ThreatIntelSet, () => GuardDuty.ThreatIntelSetProvider()),
          ImageBuilder.ComponentProvider(),
          ImageBuilder.DistributionConfigurationProvider(),
          ImageBuilder.ImagePipelineProvider(),
          ImageBuilder.ImageRecipeProvider(),
          ImageBuilder.InfrastructureConfigurationProvider(),
          flociDual(Inspector2.CisScanConfiguration, () =>
            Inspector2.CisScanConfigurationProvider(),
          ),
          flociDual(Inspector2.Enabler, () => Inspector2.EnablerProvider()),
          flociDual(Inspector2.Filter, () => Inspector2.FilterProvider()),
          InternetMonitor.MonitorProvider(),
          flociDual(SecurityHub.ActionTarget, () => SecurityHub.ActionTargetProvider()),
          flociDual(SecurityHub.AutomationRule, () => SecurityHub.AutomationRuleProvider()),
          flociDual(SecurityHub.FindingAggregator, () => SecurityHub.FindingAggregatorProvider()),
          flociDual(SecurityHub.Hub, () => SecurityHub.HubProvider()),
          flociDual(SecurityHub.Insight, () => SecurityHub.InsightProvider()),
          SecurityLake.DataLakeProvider(),
          SecurityLake.AwsLogSourceProvider(),
          SecurityLake.CustomLogSourceProvider(),
          SecurityLake.ExceptionSubscriptionProvider(),
          SecurityLake.SubscriberProvider(),
          SecurityLake.SubscriberNotificationProvider(),
          flociDual(Detective.Graph, () => Detective.GraphProvider()),
          FMS.AdminAccountProvider(),
          flociDual(Macie2.Session, () => Macie2.SessionProvider()),
          flociDual(Macie2.ClassificationJob, () => Macie2.ClassificationJobProvider()),
          flociDual(Macie2.AllowList, () => Macie2.AllowListProvider()),
          flociDual(Macie2.CustomDataIdentifier, () => Macie2.CustomDataIdentifierProvider()),
          flociDual(Macie2.FindingsFilter, () => Macie2.FindingsFilterProvider()),
          flociDual(RAM.Permission, () => RAM.PermissionProvider()),
          flociDual(RAM.ResourceShare, () => RAM.ResourceShareProvider()),
        ),
        Layer.mergeAll(
          AIOps.InvestigationGroupProvider(),
          AuditManager.AssessmentProvider(),
          AuditManager.ControlProvider(),
          AuditManager.FrameworkProvider(),
          ApplicationSignals.DiscoveryProvider(),
          ApplicationSignals.GroupingConfigurationProvider(),
          ApplicationSignals.InstrumentationConfigurationProvider(),
          ApplicationSignals.ServiceLevelObjectiveProvider(),
          LicenseManager.LicenseConfigurationProvider(),
          LexV2.BotProvider(),
          LexV2.BotAliasProvider(),
          LexV2.BotLocaleProvider(),
          LexV2.BotVersionProvider(),
          LexV2.IntentProvider(),
          LexV2.SlotTypeProvider(),
          S3Files.FileSystemProvider(),
          S3Files.AccessPointProvider(),
          flociDual(S3Tables.TableBucket, () => S3Tables.TableBucketProvider()),
          flociDual(S3Tables.Namespace, () => S3Tables.NamespaceProvider()),
          flociDual(S3Tables.Table, () => S3Tables.TableProvider()),
          flociDual(S3Vectors.VectorBucket, () => S3Vectors.VectorBucketProvider()),
          flociDual(S3Vectors.Index, () => S3Vectors.IndexProvider()),
          flociDual(SageMaker.Model, () => SageMaker.ModelProvider()),
          flociDual(SageMaker.EndpointConfig, () => SageMaker.EndpointConfigProvider()),
          flociDual(SageMaker.Endpoint, () => SageMaker.EndpointProvider()),
          flociDual(SageMaker.FeatureGroup, () => SageMaker.FeatureGroupProvider()),
          flociDual(SageMaker.Cluster, () => SageMaker.ClusterProvider()),
          flociDual(SageMaker.ClusterSchedulerConfig, () =>
            SageMaker.ClusterSchedulerConfigProvider(),
          ),
          flociDual(SageMaker.ComputeQuota, () => SageMaker.ComputeQuotaProvider()),
          flociDual(Account.AccountName, () => Account.AccountNameProvider()),
          flociDual(Account.AlternateContact, () => Account.AlternateContactProvider()),
          flociDual(Account.ContactInformation, () => Account.ContactInformationProvider()),
          flociDual(Account.Region, () => Account.RegionProvider()),
          Amplify.AppProvider(),
          Amplify.BranchProvider(),
          ECRPublic.PublicRepositoryProvider(),
          VpcLattice.ServiceNetworkProvider(),
          VpcLattice.ServiceProvider(),
          VpcLattice.ServiceNetworkVpcAssociationProvider(),
          VpcLattice.AuthPolicyProvider(),
          VpcLattice.ResourcePolicyProvider(),
          VpcLattice.ServiceNetworkServiceAssociationProvider(),
          VpcLattice.TargetGroupProvider(),
          VpcLattice.ListenerProvider(),
          VpcLattice.RuleProvider(),
          VpcLattice.AccessLogSubscriptionProvider(),
          flociDual(MWAA.Environment, () => MWAA.EnvironmentProvider()),
          MWAAServerless.WorkflowProvider(),
          Location.ApiKeyProvider(),
          Location.MapProvider(),
          Location.PlaceIndexProvider(),
          Location.RouteCalculatorProvider(),
          Location.GeofenceCollectionProvider(),
          Location.TrackerProvider(),
          Location.TrackerConsumerProvider(),
          Forecast.DatasetGroupProvider(),
          Forecast.DatasetProvider(),
          FraudDetector.DetectorProvider(),
          FraudDetector.DetectorVersionProvider(),
          FraudDetector.EntityTypeProvider(),
          FraudDetector.EventTypeProvider(),
          FraudDetector.LabelProvider(),
          FraudDetector.ListProvider(),
          FraudDetector.OutcomeProvider(),
          FraudDetector.VariableProvider(),
          Personalize.SchemaProvider(),
          Personalize.DatasetGroupProvider(),
          Personalize.DatasetProvider(),
          Personalize.EventTrackerProvider(),
          PinpointSMSVoiceV2.ConfigurationSetProvider(),
          PinpointSMSVoiceV2.EventDestinationProvider(),
          PinpointSMSVoiceV2.OptOutListProvider(),
          PinpointSMSVoiceV2.PhoneNumberProvider(),
          flociDual(IoT.Thing, () => IoT.ThingProvider()),
          flociDual(IoT.ThingType, () => IoT.ThingTypeProvider()),
          flociDual(IoT.Policy, () => IoT.PolicyProvider()),
          flociDual(IoT.TopicRule, () => IoT.TopicRuleProvider()),
          IoTFleetWise.CampaignProvider(),
          IoTFleetWise.DecoderManifestProvider(),
          IoTFleetWise.FleetProvider(),
          IoTFleetWise.ModelManifestProvider(),
          IoTFleetWise.SignalCatalogProvider(),
          IoTFleetWise.StateTemplateProvider(),
          IoTFleetWise.VehicleProvider(),
          IoTManagedIntegrations.CredentialLockerProvider(),
          IoTManagedIntegrations.DestinationProvider(),
          IoTManagedIntegrations.ManagedThingProvider(),
          IoTManagedIntegrations.NotificationConfigurationProvider(),
          IoTSiteWise.AssetModelProvider(),
          IoTSiteWise.AssetProvider(),
          IoTSiteWise.GatewayProvider(),
          IoTWireless.DestinationProvider(),
          IoTWireless.DeviceProfileProvider(),
          IoTWireless.ServiceProfileProvider(),
          IoTWireless.WirelessDeviceProvider(),
          IoTWireless.WirelessGatewayProvider(),
          ResourceGroups.GroupProvider(),
          RolesAnywhere.CrlProvider(),
          RolesAnywhere.ProfileProvider(),
          RolesAnywhere.TrustAnchorProvider(),
          Synthetics.CanaryProvider(),
          Synthetics.GroupProvider(),
          SSMContacts.ContactProvider(),
          SSMContacts.ContactChannelProvider(),
          SSMContacts.PlanProvider(),
          SSMContacts.RotationProvider(),
          SSMIncidents.ReplicationSetProvider(),
          SSMIncidents.ResponsePlanProvider(),
        ),
        Layer.mergeAll(
          FinSpace.EnvironmentProvider(),
          FinSpace.KxClusterProvider(),
          FinSpace.KxDatabaseProvider(),
          FinSpace.KxEnvironmentProvider(),
          flociDual(ControlTower.EnabledBaseline, () => ControlTower.EnabledBaselineProvider()),
          flociDual(ControlTower.EnabledControl, () => ControlTower.EnabledControlProvider()),
          flociDual(ControlTower.LandingZone, () => ControlTower.LandingZoneProvider()),
          flociDual(CostAndUsageReport.ReportDefinition, () =>
            CostAndUsageReport.ReportDefinitionProvider(),
          ),
          CostExplorer.AnomalyMonitorProvider(),
          CostExplorer.AnomalySubscriptionProvider(),
          CostExplorer.CostCategoryProvider(),
          Rbin.RuleProvider(),
          flociDual(RUM.AppMonitor, () => RUM.AppMonitorProvider()),
          flociDual(RUM.MetricsDestination, () => RUM.MetricsDestinationProvider()),
          flociDual(RUM.ResourcePolicy, () => RUM.ResourcePolicyProvider()),
          flociDual(EMR.Cluster, () => EMR.ClusterProvider()),
          flociDual(EMR.SecurityConfiguration, () => EMR.SecurityConfigurationProvider()),
          flociDual(EMR.Studio, () => EMR.StudioProvider()),
          EMRContainers.JobTemplateProvider(),
          EMRContainers.VirtualClusterProvider(),
          flociDual(EMRServerless.Application, () => EMRServerless.ApplicationProvider()),
          EntityResolution.SchemaMappingProvider(),
          EntityResolution.MatchingWorkflowProvider(),
          EntityResolution.IdNamespaceProvider(),
          EntityResolution.IdMappingWorkflowProvider(),
          Schemas.DiscovererProvider(),
          Schemas.RegistryProvider(),
          Schemas.SchemaProvider(),
          Route53Profiles.ProfileProvider(),
          Route53Profiles.ProfileAssociationProvider(),
          Route53Profiles.ProfileResourceAssociationProvider(),
          flociDual(Route53Resolver.ResolverEndpoint, () =>
            Route53Resolver.ResolverEndpointProvider(),
          ),
          flociDual(Route53Resolver.ResolverRule, () => Route53Resolver.ResolverRuleProvider()),
          flociDual(Route53Resolver.ResolverRuleAssociation, () =>
            Route53Resolver.ResolverRuleAssociationProvider(),
          ),
          Shield.ProtectionProvider(),
          Shield.ProtectionGroupProvider(),
          Shield.SubscriptionProvider(),
          Signer.ProfilePermissionProvider(),
          Signer.SigningProfileProvider(),
          SimpleDB.DomainProvider(),
          Timestream.DatabaseProvider(),
          flociDual(Timestream.DbInstance, () => Timestream.DbInstanceProvider()),
          Timestream.ScheduledQueryProvider(),
          Timestream.TableProvider(),
          flociDual(ResourceExplorer.Index, () => ResourceExplorer.IndexProvider()),
          flociDual(ResourceExplorer.View, () => ResourceExplorer.ViewProvider()),
          Notifications.ChannelAssociationProvider(),
          Notifications.EventRuleProvider(),
          Notifications.NotificationConfigurationProvider(),
          Notifications.NotificationHubProvider(),
          NotificationsContacts.EmailContactProvider(),
          flociDual(OAM.Link, () => OAM.LinkProvider()),
          flociDual(OAM.Sink, () => OAM.SinkProvider()),
          ObservabilityAdmin.TelemetryConfigProvider(),
          ObservabilityAdmin.TelemetryRuleProvider(),
          Omics.AnnotationStoreProvider(),
          Omics.ReferenceStoreProvider(),
          Omics.RunGroupProvider(),
          Omics.SequenceStoreProvider(),
          Omics.VariantStoreProvider(),
          Omics.WorkflowProvider(),
          flociDual(GlobalAccelerator.Accelerator, () => GlobalAccelerator.AcceleratorProvider()),
          flociDual(GlobalAccelerator.Listener, () => GlobalAccelerator.ListenerProvider()),
          flociDual(GlobalAccelerator.EndpointGroup, () =>
            GlobalAccelerator.EndpointGroupProvider(),
          ),
          AppRegistry.ApplicationProvider(),
          AppRegistry.AttributeGroupProvider(),
          AppRegistry.AttributeGroupAssociationProvider(),
          AppRegistry.ResourceAssociationProvider(),
          flociDual(ServiceCatalog.Portfolio, () => ServiceCatalog.PortfolioProvider()),
          flociDual(ServiceCatalog.PortfolioProductAssociation, () =>
            ServiceCatalog.PortfolioProductAssociationProvider(),
          ),
          flociDual(ServiceCatalog.PrincipalPortfolioAssociation, () =>
            ServiceCatalog.PrincipalPortfolioAssociationProvider(),
          ),
          flociDual(ServiceCatalog.Product, () => ServiceCatalog.ProductProvider()),
          flociDual(ServiceQuotas.ServiceQuotaIncreaseRequest, () =>
            ServiceQuotas.ServiceQuotaIncreaseRequestProvider(),
          ),
          S3Control.AccessPointProvider(),
          S3Control.AccessPointPolicyProvider(),
          S3Control.MultiRegionAccessPointProvider(),
          S3Control.ObjectLambdaAccessPointProvider(),
          S3Control.StorageLensConfigurationProvider(),
          flociDual(NetworkFirewall.RuleGroup, () => NetworkFirewall.RuleGroupProvider()),
          flociDual(NetworkFirewall.FirewallPolicy, () => NetworkFirewall.FirewallPolicyProvider()),
          flociDual(NetworkFirewall.Firewall, () => NetworkFirewall.FirewallProvider()),
          flociDual(NetworkFirewall.LoggingConfiguration, () =>
            NetworkFirewall.LoggingConfigurationProvider(),
          ),
          flociDual(CloudTrail.EventDataStore, () => CloudTrail.EventDataStoreProvider()),
          flociDual(CloudTrail.Trail, () => CloudTrail.TrailProvider()),
          IVS.ChannelProvider(),
          IVS.PlaybackKeyPairProvider(),
          IVS.PlaybackRestrictionPolicyProvider(),
          IVS.RecordingConfigurationProvider(),
          IVS.StreamKeyProvider(),
          IVSChat.LoggingConfigurationProvider(),
          IVSChat.RoomProvider(),
          IVSRealtime.StageProvider(),
        ),
      ),
    ),
    // The `aws-eks` Kubernetes cluster adapter is provideMerged (not just
    // provided) so the cluster-agnostic `Kubernetes.*` workload providers
    // can resolve it dynamically from the ambient stack context.
    Layer.provideMerge(EKS.EksKubernetesAdapter()),
    Layer.provideMerge(
      Layer.mergeAll(
        Command.providers(),
        KeyPairProvider(),
        RandomProvider(),
        Assets.AssetsLive,
        DockerLive,
      ),
    ),
    // Plan-executable data-source capabilities: registering the impl layers
    // at the stack level lets `Capability.execute(...)` Outputs (e.g.
    // `AWS.EC2.getAmi`) resolve during plan.
    Layer.provideMerge(EC2.GetAmiHttp),
    // Fresh per call: these derive from the environment below, and shared
    // (memoized) instances built for another environment in the same run
    // would shadow an `AWSEnvironment` provided to this layer.
    Layer.provideMerge(Layer.fresh(Region.fromEnvironment)),
    Layer.provideMerge(Layer.fresh(Credentials.fromEnvironment)),
    Layer.provideMerge(Layer.fresh(Endpoint.fromEnvironment)),
    Layer.provideMerge(providedOrDefault()),
    Layer.provideMerge(AwsAuth),
    Layer.provideMerge(CredentialsStoreLive),
    // Apply a blanket retry policy to every AWS SDK call. Like distilled's
    // `makeDefault` it retries throttling, 5xx, and Smithy `@retryable`
    // errors with exponential backoff + jitter + `RetryAfter` header
    // awareness, but with a higher attempt cap (10 vs 5) so heavy
    // parallel deploys ride out S3 `SlowDown` bursts that span more than
    // a few seconds. Bounded so real rate-limit pressure still surfaces
    // instead of masking as an indefinite hang.
    Layer.provideMerge(Layer.succeed(Retry, awsRetryFactory)),
    // In an `alchemy dev` run the AMBIENT environment — what stack
    // composition code, plan-time data sources (`AWS.EC2.getAmi`), and any
    // raw distilled call see — is the EMULATOR, so dev needs no real
    // credentials and no call-site routing. The providers above were built
    // beneath the live chain and keep it (their lifecycle ops close over
    // their build context): live-mode and mode-agnostic resources still hit
    // the real cloud, and local variants override per-resource via their
    // registered data plane. `Layer.merge`'s second layer wins duplicate
    // tags, which is exactly the shadowing we want; `Alchemy.remote()`
    // resources stay live through the per-resource binding routing.
    (base) =>
      Layer.unwrap(
        Effect.gen(function* () {
          const mode = yield* defaultProviderMode;
          return mode === "local" ? Layer.merge(base, flociServices()) : base;
        }),
      ),
    Layer.orDie,
  );

// Node socket-level error codes that indicate a transient network failure.
const TRANSIENT_NETWORK_CODES = new Set([
  "ETIMEDOUT",
  "ECONNRESET",
  "ECONNREFUSED",
  "EPIPE",
  "ENETUNREACH",
  "ENETDOWN",
  "EHOSTUNREACH",
  "EAI_AGAIN",
]);
// Transport-termination signatures that undici/node surface as plain messages
// (e.g. a `fetch` whose socket dies mid-body throws `TypeError: terminated`).
const TRANSIENT_NETWORK_PATTERN =
  /terminated|socket hang up|other side closed|fetch failed|read ETIMEDOUT|ECONNRESET|ETIMEDOUT/i;

// Walk an error's cause chain looking for a transient transport failure. Used
// to tell a Decode/EmptyBody error caused by a dropped connection (retryable)
// apart from one caused by a genuinely malformed body (permanent).
const hasTransientNetworkCause = (cause: unknown, depth = 0): boolean => {
  if (cause == null || depth > 8) return false;
  if (typeof cause === "string") return TRANSIENT_NETWORK_PATTERN.test(cause);
  if (typeof cause !== "object") return false;
  const code = (cause as { code?: unknown }).code;
  if (typeof code === "string" && TRANSIENT_NETWORK_CODES.has(code)) {
    return true;
  }
  const message = (cause as { message?: unknown }).message;
  if (typeof message === "string" && TRANSIENT_NETWORK_PATTERN.test(message)) {
    return true;
  }
  const nested = (cause as { cause?: unknown }).cause;
  return nested !== undefined && nested !== cause
    ? hasTransientNetworkCause(nested, depth + 1)
    : false;
};

// Error codes raised while failing to even open a connection. bun's fetch
// reports an unresolvable hostname (NXDOMAIN — e.g. an AWS service with no
// endpoint in the ambient region, like IoT Managed Integrations outside its
// launch regions) as `ConnectionRefused`/`FailedToOpenSocket`, which is
// indistinguishable from a live-but-refusing host. These failures are almost
// always permanent (wrong region, wrong endpoint), so they get a small retry
// budget instead of the full 16-attempt transport budget — enough to ride out
// a momentary blip, but a nonexistent endpoint fails in ~1.5s, not ~60s.
const CONNECT_FAILURE_CODES = new Set([
  "ConnectionRefused", // bun: connect failed (includes NXDOMAIN)
  "FailedToOpenSocket", // bun: socket open failed (includes NXDOMAIN)
  "ENOTFOUND", // node: DNS name not found
  "EAI_NONAME", // node: DNS name not found
  "ECONNREFUSED", // node: TCP connect refused
]);

const hasConnectFailureCause = (cause: unknown, depth = 0): boolean => {
  if (cause == null || typeof cause !== "object" || depth > 8) return false;
  const code = (cause as { code?: unknown }).code;
  if (typeof code === "string" && CONNECT_FAILURE_CODES.has(code)) return true;
  const nested = (cause as { cause?: unknown }).cause;
  return nested !== undefined && nested !== cause
    ? hasConnectFailureCause(nested, depth + 1)
    : false;
};

const isConnectFailure = (error: unknown): boolean =>
  HttpClientError.isHttpClientError(error) &&
  error.reason._tag === "TransportError" &&
  hasConnectFailureCause(error.reason);

// TODO(sam): remove this once it's upstreamed to distilled
const isHttpTransportError = (error: unknown): boolean => {
  if (!HttpClientError.isHttpClientError(error)) return false;
  const reason = error.reason;
  const tag = reason._tag;
  if (tag === "TransportError") return true;
  // A Decode/EmptyBody error is only transient when its underlying cause is a
  // terminated/reset connection (e.g. a `read ETIMEDOUT` while streaming the
  // body surfaces as a `DecodeError`). A genuine malformed-body decode is
  // permanent — retrying it would only waste the budget and mask the bug — so
  // gate on the cause chain rather than the tag.
  if (tag === "DecodeError" || tag === "EmptyBodyError") {
    return hasTransientNetworkCause(reason);
  }
  if (
    tag === "StatusCodeError" &&
    "response" in error.reason &&
    error.reason.response.status >= 500
  ) {
    return true;
  }
  return false;
};

const awsRetryFactory: RetryFactory = (lastError) => {
  // The factory runs once per API call, so this counter is call-scoped. It
  // caps connect-phase failures (see CONNECT_FAILURE_CODES) at 3 retries
  // within the overall schedule below.
  let connectFailures = 0;
  return {
    while: (error) => {
      if (isConnectFailure(error)) return ++connectFailures <= 3;
      return (
        isTransientError(error) ||
        isThrottlingError(error) ||
        isRetryable(error) ||
        isHttpTransportError(error)
      );
    },
    // Transient transport failures (e.g. a sustained `read ETIMEDOUT` blip
    // against a control-plane endpoint) can outlast a 10-attempt budget. With
    // the 5s cap below, the extra attempts add bounded backoff while making
    // the network-flake recovery materially more robust.
    schedule: Schedule.max([
      pipe(
        Schedule.exponential(Duration.millis(200), 2),
        Schedule.modifyDelay(
          Effect.fn(function* ({ duration }) {
            const error = yield* Ref.get(lastError);
            if (isThrottlingError(error)) {
              // Throttling: floor at 500ms (matches distilled default).
              if (Duration.toMillis(duration) < 500) {
                return Duration.toMillis(Duration.millis(500));
              }
            }
            return Duration.toMillis(duration);
          }),
        ),
        capped(Duration.seconds(5)),
        jittered,
      ),
      Schedule.recurs(15),
    ]),
  };
};
