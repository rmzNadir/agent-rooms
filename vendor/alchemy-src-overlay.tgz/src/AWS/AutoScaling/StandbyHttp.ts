import * as autoscaling from "@distilled.cloud/aws/auto-scaling";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as AWSBindings from "../AWSBindings.ts";
import type { AutoScalingGroup } from "./AutoScalingGroup.ts";
import { Standby, type EnterStandbyRequest, type ExitStandbyRequest } from "./Standby.ts";

// Bespoke (not the shared scaffold): a multi-operation client over
// `enterStandby` + `exitStandby` behind one IAM grant.
export const StandbyHttp = Layer.effect(
  Standby,
  Effect.gen(function* () {
    const enter = yield* AWSBindings.withCredentials(autoscaling.enterStandby);
    const exit = yield* AWSBindings.withCredentials(autoscaling.exitStandby);

    return Effect.fn(function* (group: AutoScalingGroup) {
      const AutoScalingGroupName = yield* group.autoScalingGroupName;
      if (!globalThis.__ALCHEMY_RUNTIME__) {
        yield* AWSBindings.bind`AWS.AutoScaling.Standby(${group})`({
          policyStatements: [
            {
              Effect: "Allow",
              Action: ["autoscaling:EnterStandby", "autoscaling:ExitStandby"],
              Resource: [group.autoScalingGroupArn],
            },
          ],
        });
      }
      return {
        enter: Effect.fn(`AWS.AutoScaling.EnterStandby(${group.LogicalId})`)(function* (
          request: EnterStandbyRequest,
        ) {
          return yield* enter({
            ...request,
            AutoScalingGroupName: yield* AutoScalingGroupName,
          });
        }),
        exit: Effect.fn(`AWS.AutoScaling.ExitStandby(${group.LogicalId})`)(function* (
          request: ExitStandbyRequest,
        ) {
          return yield* exit({
            ...request,
            AutoScalingGroupName: yield* AutoScalingGroupName,
          });
        }),
      };
    });
  }),
);
